-keep class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**
-assumenosideeffects class kotlin.jvm.internal.Intrinsics {
    public static void check*(...);
    public static void throw*(...);
}
