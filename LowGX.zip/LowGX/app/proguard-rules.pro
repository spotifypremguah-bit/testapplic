-keep class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**
-assumenosideeffects class kotlin.jvm.internal.Intrinsics {
    public static void check*(...);
    public static void throw*(...);
}

# --- Obfuscation & shrinking hardening ---

# Repack all obfuscated classes into a single package to flatten the
# namespace and make the package structure harder to read.
-repackageclasses ''
-allowaccessmodification
-overloadaggressively

# Run optimization and name-mangling passes multiple times for a
# smaller, more thoroughly obfuscated result.
-optimizationpasses 5
-mergeinterfacesaggressively

# Strip debugging aids that make reversing easier.
-renamesourcefileattribute ''
-keepattributes !SourceFile,!LineNumberTable,!LocalVariableTable,!LocalVariableTypeTable

# Drop logging calls in release builds.
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}
