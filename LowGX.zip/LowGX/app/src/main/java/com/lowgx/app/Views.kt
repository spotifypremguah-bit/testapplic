package com.lowgx.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.widget.ScrollView

private fun View.dpf(v: Float) = v * resources.displayMetrics.density

/** Kotak Saturation (x) / Value (y) untuk color picker. */
class SatValView(c: Context) : View(c) {
    var hue = 0f
    var sat = 1f
    var value = 1f
    var onChange: (() -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private var shaderHue = -1f
    private var shaderW = 0
    private var shaderH = 0
    private var hShader: Shader? = null
    private var vShader: Shader? = null

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (hShader == null || shaderHue != hue || shaderW != width || shaderH != height) {
            hShader = LinearGradient(0f, 0f, w, 0f, Color.WHITE,
                Color.HSVToColor(floatArrayOf(hue, 1f, 1f)), Shader.TileMode.CLAMP)
            vShader = LinearGradient(0f, 0f, 0f, h, Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP)
            shaderHue = hue; shaderW = width; shaderH = height
        }
        rect.set(0f, 0f, w, h)
        val r = dpf(16f)
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        p.style = Paint.Style.FILL
        p.shader = hShader
        canvas.drawRect(rect, p)
        p.shader = vShader
        canvas.drawRect(rect, p)
        p.shader = null
        canvas.restore()

        val x = sat * w
        val y = (1f - value) * h
        p.style = Paint.Style.STROKE
        p.strokeWidth = dpf(3f)
        p.color = Color.WHITE
        canvas.drawCircle(x, y, dpf(11f), p)
        p.strokeWidth = dpf(1f)
        p.color = 0x66000000
        canvas.drawCircle(x, y, dpf(13f), p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        sat = (e.x / width).coerceIn(0f, 1f)
        value = 1f - (e.y / height).coerceIn(0f, 1f)
        invalidate()
        onChange?.invoke()
        return true
    }
}

/** Slider warna (hue) 0..360. */
class HueBar(c: Context) : View(c) {
    var hue = 0f
    var onChange: (() -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var shader: Shader? = null
    private var shaderW = 0

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (shader == null || shaderW != width) {
            val colors = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
            shader = LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.CLAMP)
            shaderW = width
        }
        val pad = h / 2f
        rect.set(pad, h * 0.3f, w - pad, h * 0.7f)
        p.style = Paint.Style.FILL
        p.shader = shader
        canvas.drawRoundRect(rect, h * 0.2f, h * 0.2f, p)
        p.shader = null

        val x = pad + (hue / 360f) * (w - 2 * pad)
        p.color = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        canvas.drawCircle(x, h / 2f, h * 0.42f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dpf(3f)
        p.color = Color.WHITE
        canvas.drawCircle(x, h / 2f, h * 0.42f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val pad = height / 2f
        hue = (((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)) * 360f
        invalidate()
        onChange?.invoke()
        return true
    }
}

/** Switch kecil ber-animasi (tanpa library). */
class Toggle(
    c: Context,
    private val onTrack: Int, private val offTrack: Int, private val offStroke: Int,
    private val onThumb: Int, private val offThumb: Int
) : View(c) {
    var checked = false
        private set
    private var f = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val eval = ArgbEvaluator()

    fun set(v: Boolean, animate: Boolean) {
        checked = v
        val target = if (v) 1f else 0f
        if (animate) {
            ValueAnimator.ofFloat(f, target).apply {
                duration = 170
                addUpdateListener { f = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            f = target
            invalidate()
        }
    }

    override fun onMeasure(w: Int, h: Int) =
        setMeasuredDimension(dpf(52f).toInt(), dpf(32f).toInt())

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val sw = dpf(2f)
        rect.set(sw / 2, sw / 2, w - sw / 2, h - sw / 2)
        p.style = Paint.Style.FILL
        p.color = eval.evaluate(f, offTrack, onTrack) as Int
        canvas.drawRoundRect(rect, h / 2, h / 2, p)
        if (f < 1f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = sw
            p.color = offStroke
            p.alpha = ((1f - f) * 255).toInt()
            canvas.drawRoundRect(rect, h / 2, h / 2, p)
            p.alpha = 255
        }
        p.style = Paint.Style.FILL
        p.color = eval.evaluate(f, offThumb, onThumb) as Int
        val cx = h / 2 + f * (w - h)
        val r = h * (0.26f + 0.12f * f)
        canvas.drawCircle(cx, h / 2, r, p)
    }
}

/** ScrollView dengan tinggi maksimum (untuk dialog panjang). */
class MaxHeightScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) =
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
}

/** Slider bertingkat (gaya Material 3): track tebal, thumb berupa garis vertikal. */
class StepSlider(c: Context) : View(c) {
    var steps = 8
    var index = 0
        set(v) { val n = v.coerceIn(0, steps - 1); if (n != field) { field = n; invalidate() } }
    var trackColor = Color.DKGRAY
    var fillColor = Color.LTGRAY
    var thumbColor = Color.LTGRAY
    var onChange: ((Int) -> Unit)? = null
    var onRelease: ((Int) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(resolveSize(suggestedMinimumWidth, wSpec), dpf(44f).toInt())
    }

    private fun padX() = dpf(6f)

    private fun thumbX(): Float {
        val w = width - 2 * padX()
        return padX() + w * (index.toFloat() / (steps - 1).coerceAtLeast(1))
    }

    override fun onDraw(canvas: Canvas) {
        val cy = height / 2f
        val th = dpf(14f)
        val r = th / 2f
        val gap = dpf(6f)
        val tx = thumbX()
        val left = padX()
        val right = width - padX()

        p.style = Paint.Style.FILL
        // sisi kanan (track kosong)
        if (right - (tx + gap) > 1f) {
            p.color = trackColor
            rect.set(tx + gap, cy - th / 2, right, cy + th / 2)
            canvas.drawRoundRect(rect, r, r, p)
        }
        // sisi kiri (terisi)
        if ((tx - gap) - left > 1f) {
            p.color = fillColor
            rect.set(left, cy - th / 2, tx - gap, cy + th / 2)
            canvas.drawRoundRect(rect, r, r, p)
        }
        // thumb
        p.color = thumbColor
        val tw = dpf(4f)
        rect.set(tx - tw / 2, cy - dpf(16f), tx + tw / 2, cy + dpf(16f))
        canvas.drawRoundRect(rect, tw / 2, tw / 2, p)
    }

    private fun idxAt(x: Float): Int {
        val w = (width - 2 * padX()).coerceAtLeast(1f)
        val f = ((x - padX()) / w).coerceIn(0f, 1f)
        return Math.round(f * (steps - 1))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                move(idxAt(e.x))
            }
            MotionEvent.ACTION_MOVE -> move(idxAt(e.x))
            MotionEvent.ACTION_UP -> { move(idxAt(e.x)); onRelease?.invoke(index) }
            MotionEvent.ACTION_CANCEL -> onRelease?.invoke(index)
        }
        return true
    }

    private fun move(i: Int) {
        if (i != index) { index = i; onChange?.invoke(i) }
    }
}
