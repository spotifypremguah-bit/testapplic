package com.lowgx.app

import android.content.Context
import android.graphics.Color
import android.os.Build
import kotlin.math.abs

/** Semua warna UI dalam satu objek ringan. */
class Palette(
    val night: Boolean,
    val bg: Int, val card: Int, val alt: Int,
    val accent: Int, val onAccent: Int,
    val container: Int, val onContainer: Int,
    val text: Int, val sub: Int,
    val err: Int, val errBg: Int, val onErrBg: Int,
    val ripple: Int,
    val navSel: Int, val navSelContent: Int
)

object Themes {

    fun hsl(h: Float, s: Float, l: Float): Int {
        val ss = s.coerceIn(0f, 1f)
        val ll = l.coerceIn(0f, 1f)
        val c = (1f - abs(2f * ll - 1f)) * ss
        val hp = (((h % 360f) + 360f) % 360f) / 60f
        val x = c * (1f - abs(hp % 2f - 1f))
        val r: Float; val g: Float; val b: Float
        when {
            hp < 1f -> { r = c; g = x; b = 0f }
            hp < 2f -> { r = x; g = c; b = 0f }
            hp < 3f -> { r = 0f; g = c; b = x }
            hp < 4f -> { r = 0f; g = x; b = c }
            hp < 5f -> { r = x; g = 0f; b = c }
            else -> { r = c; g = 0f; b = x }
        }
        val m = ll - c / 2f
        fun ch(v: Float) = ((v + m) * 255f + 0.5f).toInt().coerceIn(0, 255)
        return Color.rgb(ch(r), ch(g), ch(b))
    }

    fun build(ctx: Context, dynamic: Boolean, seed: Int, dark: Boolean, amoled: Boolean): Palette =
        if (dynamic && Build.VERSION.SDK_INT >= 31) dynamicPalette(ctx, dark, amoled)
        else seeded(seed, dark, amoled)

    private fun seeded(seed: Int, dark: Boolean, amoled: Boolean): Palette {
        val hsv = FloatArray(3)
        Color.colorToHSV(seed, hsv)
        val h = hsv[0]
        val sa = if (hsv[1] < 0.12f) hsv[1] else hsv[1].coerceIn(0.4f, 0.85f)
        val sn = sa * 0.14f
        return if (dark) Palette(
            night = true,
            bg = if (amoled) Color.BLACK else hsl(h, sn, 0.075f),
            card = hsl(h, sn, if (amoled) 0.13f else 0.15f),
            alt = if (amoled) hsl(h, sn, 0.07f) else hsl(h, sn, 0.105f),
            accent = hsl(h, sa, 0.76f), onAccent = hsl(h, sa, 0.12f),
            container = hsl(h, sa * 0.7f, 0.24f), onContainer = hsl(h, sa, 0.9f),
            text = hsl(h, sn, 0.9f), sub = hsl(h, sn, 0.72f),
            err = 0xFFF2B8B5.toInt(), errBg = 0xFF601410.toInt(), onErrBg = 0xFFFFDAD6.toInt(),
            ripple = 0x33FFFFFF,
            navSel = hsl(h, sa * 0.6f, 0.06f), navSelContent = hsl(h, sa, 0.82f)
        ) else Palette(
            night = false,
            bg = hsl(h, sn * 1.6f, 0.975f), card = hsl(h, sn * 1.5f, 0.92f),
            alt = hsl(h, sn * 1.2f, 0.985f),
            accent = hsl(h, sa, 0.34f), onAccent = Color.WHITE,
            container = hsl(h, sa * 0.8f, 0.86f), onContainer = hsl(h, sa, 0.14f),
            text = hsl(h, sn, 0.1f), sub = hsl(h, sn, 0.32f),
            err = 0xFFB3261E.toInt(), errBg = 0xFFF9DEDC.toInt(), onErrBg = 0xFF410E0B.toInt(),
            ripple = 0x22000000,
            navSel = hsl(h, sa * 0.6f, 0.1f), navSelContent = hsl(h, sa, 0.85f)
        )
    }

    private fun dynamicPalette(ctx: Context, dark: Boolean, amoled: Boolean): Palette {
        fun c(id: Int) = ctx.getColor(id)
        return if (dark) Palette(
            night = true,
            bg = if (amoled) Color.BLACK else c(android.R.color.system_neutral1_900),
            card = if (amoled) c(android.R.color.system_neutral1_900) else c(android.R.color.system_neutral1_800),
            alt = if (amoled) Color.BLACK else c(android.R.color.system_neutral1_900),
            accent = c(android.R.color.system_accent1_200), onAccent = c(android.R.color.system_accent1_800),
            container = c(android.R.color.system_accent1_700), onContainer = c(android.R.color.system_accent1_100),
            text = c(android.R.color.system_neutral1_100), sub = c(android.R.color.system_neutral2_300),
            err = 0xFFF2B8B5.toInt(), errBg = 0xFF601410.toInt(), onErrBg = 0xFFFFDAD6.toInt(),
            ripple = 0x33FFFFFF,
            navSel = c(android.R.color.system_accent1_900), navSelContent = c(android.R.color.system_accent1_200)
        ) else Palette(
            night = false,
            bg = c(android.R.color.system_neutral1_10), card = c(android.R.color.system_neutral1_100),
            alt = c(android.R.color.system_neutral1_50),
            accent = c(android.R.color.system_accent1_600), onAccent = Color.WHITE,
            container = c(android.R.color.system_accent1_100), onContainer = c(android.R.color.system_accent1_900),
            text = c(android.R.color.system_neutral1_900), sub = c(android.R.color.system_neutral2_700),
            err = 0xFFB3261E.toInt(), errBg = 0xFFF9DEDC.toInt(), onErrBg = 0xFF410E0B.toInt(),
            ripple = 0x22000000,
            navSel = c(android.R.color.system_accent1_900), navSelContent = c(android.R.color.system_accent1_200)
        )
    }
}
