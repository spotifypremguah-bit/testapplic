package com.lowgx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

// Shared with the settings page: index = saved choice.
val FPS_SP = floatArrayOf(12f, 15f, 18f)
val FPS_OPA = intArrayOf(102, 166, 230)
val FPS_MS = longArrayOf(500L, 1000L, 2000L)

class FpsService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    @Volatile private var alive = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean("fps_on", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!prefs.getBoolean("fps_on", false) || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        applyOverlay()
        if (!alive) {
            alive = true
            worker = Thread { loop() }.apply { isDaemon = true; start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        worker?.interrupt()
        try { tv?.let { wm?.removeView(it) } } catch (_: Throwable) { }
        tv = null
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "FPS counter", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FpsService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_speed)
            .setContentTitle("FPS counter")
            .setContentText("Floating counter is on")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID, n)
        }
    }

    private fun applyOverlay() {
        try {
            val w = wm ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { wm = it }
            val d = resources.displayMetrics.density
            val size = prefs.getInt("fps_size", 1).coerceIn(0, 2)
            val opa = prefs.getInt("fps_opa", 1).coerceIn(0, 2)
            val pos = prefs.getInt("fps_pos", 0).coerceIn(0, 2)

            val t = tv ?: TextView(this).also {
                tv = it
                it.text = "-- FPS"
                it.setTextColor(Color.WHITE)
                it.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            }
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, FPS_SP[size])
            t.setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            t.background = GradientDrawable().apply {
                setColor(Color.argb(FPS_OPA[opa], 0, 0, 0))
                cornerRadius = 10 * d
            }

            val p = lp ?: WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).also { lp = it }
            p.gravity = Gravity.TOP or when (pos) {
                0 -> Gravity.START
                1 -> Gravity.CENTER_HORIZONTAL
                else -> Gravity.END
            }
            p.x = if (pos == 1) 0 else (12 * d).toInt()
            p.y = (28 * d).toInt()

            if (t.parent == null) w.addView(t, p) else w.updateViewLayout(t, p)
        } catch (_: Throwable) { }
    }

    // ───────── measuring ─────────

    private fun loop() {
        var cands: List<String> = emptyList()
        var ci = 0
        var tick = 0
        while (alive) {
            val ms = FPS_MS[prefs.getInt("fps_int", 1).coerceIn(0, 2)]
            val text: String
            if (!Shell.granted()) {
                text = "Shizuku?"
            } else {
                if (tick % 4 == 0 || cands.isEmpty()) {
                    val pkg = foregroundPkg()
                    val fresh = if (pkg.isEmpty()) emptyList() else layersFor(pkg)
                    if (fresh != cands) ci = 0
                    cands = fresh
                }
                tick++
                if (cands.isEmpty()) {
                    text = "-- FPS"
                } else {
                    val layer = cands[ci % cands.size].replace("'", "'\\''")
                    val fps = parseFps(Shell.run("dumpsys SurfaceFlinger --latency '$layer'").second)
                    if (fps == null) {
                        ci = (ci + 1) % cands.size // this layer has no frames, try the next one
                        text = "-- FPS"
                    } else {
                        text = "$fps FPS"
                    }
                }
            }
            ui.post { tv?.text = text }
            try { Thread.sleep(ms) } catch (_: InterruptedException) { break }
        }
    }

    private fun foregroundPkg(): String {
        val out = Shell.run("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'").second
        val m = Regex("mCurrentFocus=.*? ([A-Za-z0-9._]+)/").find(out)
            ?: Regex("mFocusedApp=.*? ([A-Za-z0-9._]+)/").find(out)
        return m?.groupValues?.get(1).orEmpty()
    }

    private fun layersFor(pkg: String): List<String> {
        val all = Shell.run("dumpsys SurfaceFlinger --list").second.lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.contains("Background for") && !it.contains("Bounds for") }
        val sv = all.filter { it.startsWith("SurfaceView") }
        val blast = sv.filter { it.contains("BLAST") }
        return (blast + sv + all).distinct()
    }

    /** Parses `dumpsys SurfaceFlinger --latency` and returns frames per second, or null if no data. */
    private fun parseFps(out: String): Int? {
        val lines = out.lines()
        if (lines.size < 3) return null
        val ts = ArrayList<Long>()
        for (i in 1 until lines.size) {
            val p = lines[i].trim().split(Regex("\\s+"))
            if (p.size < 3) continue
            val v = p[1].toLongOrNull() ?: continue
            if (v > 0L && v != Long.MAX_VALUE) ts.add(v)
        }
        if (ts.isEmpty()) return null
        var last = ts[0]
        for (v in ts) if (v > last) last = v
        if (System.nanoTime() - last > 1_500_000_000L) return 0
        val recent = ts.filter { last - it <= 1_000_000_000L }.sorted()
        if (recent.size < 2) return recent.size
        val span = recent.last() - recent.first()
        return if (span <= 0L) recent.size else Math.round((recent.size - 1) * 1e9 / span).toInt()
    }

    companion object {
        const val ACTION_STOP = "com.lowgx.app.STOP_FPS"
        private const val CH = "fps"
        private const val ID = 7
    }
}
