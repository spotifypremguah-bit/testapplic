package com.lowgx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.animation.ValueAnimator
import android.content.res.Configuration
import android.graphics.Point
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

// Shared with the settings page: index = saved choice.
val FPS_SP = floatArrayOf(12f, 15f, 18f)
val FPS_OPA = intArrayOf(102, 166, 230)
val FPS_MS = longArrayOf(100L, 250L, 500L)

/**
 * Floating FPS chip, Pixel Game Dashboard style: it can be dragged anywhere but always
 * settles on the left or right edge of the screen.
 *
 * FPS comes from SurfaceFlinger TimeStats (`averageFPS` of the foreground app's layer),
 * read through Shizuku.
 */
class FpsService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    @Volatile private var alive = false
    private var worker: Thread? = null
    private var dragging = false
    private var snap: ValueAnimator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean("fps_on", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!prefs.getBoolean("fps_on", false) || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        applyOverlay()
        if (!alive) {
            alive = true
            worker = Thread { loop() }.apply { isDaemon = true; start() }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.post { applyOverlay() }
    }

    override fun onDestroy() {
        alive = false
        worker?.interrupt()
        snap?.cancel()
        try { tv?.let { wm?.removeView(it) } } catch (_: Throwable) { }
        tv = null
        Thread { Shell.run("dumpsys SurfaceFlinger --timestats -disable") }.start()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "FPS counter", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FpsService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_speed)
            .setContentTitle("FPS counter")
            .setContentText("Floating counter is on")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID, n)
        }
    }

    // ───────── overlay ─────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        val w = wm!!
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = w.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            Point().also { w.defaultDisplay.getRealSize(it) }
        }
    }

    private fun chipSize(t: TextView): Point {
        t.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        return Point(t.measuredWidth, t.measuredHeight)
    }

    private fun side() = prefs.getInt("fps_side", 1).coerceIn(0, 1)

    private fun shape(t: TextView, side: Int) {
        val opa = prefs.getInt("fps_opa", 1).coerceIn(0, 2)
        val r = dp(10).toFloat()
        t.background = GradientDrawable().apply {
            setColor(Color.argb(FPS_OPA[opa], 0, 0, 0))
            // flat on the edge it docks to, rounded on the inner side
            cornerRadii = if (side == 1) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        }
    }

    /** Places the chip on its saved edge at its saved height. */
    private fun dock() {
        val t = tv ?: return
        val p = lp ?: return
        val s = screen()
        val c = chipSize(t)
        val sd = side()
        shape(t, sd)
        p.gravity = Gravity.TOP or (if (sd == 1) Gravity.END else Gravity.START)
        p.x = 0
        val margin = dp(24)
        val maxY = (s.y - c.y - margin).coerceAtLeast(margin)
        p.y = (prefs.getFloat("fps_y", 0.3f) * s.y).toInt().coerceIn(margin, maxY)
        try { wm?.updateViewLayout(t, p) } catch (_: Throwable) { }
    }

    private fun applyOverlay() {
        try {
            val w = wm ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { wm = it }
            val size = prefs.getInt("fps_size", 1).coerceIn(0, 2)

            val t = tv ?: TextView(this).also {
                tv = it
                it.text = "Idle"
                it.gravity = Gravity.CENTER
                it.setTextColor(Color.WHITE)
                it.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                it.setOnTouchListener { v, e -> onDrag(v, e) }
            }
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, FPS_SP[size])
            t.setPadding(dp(10), dp(5), dp(10), dp(5))
            t.minWidth = (t.paint.measureText("000 FPS") + dp(20)).toInt()

            val p = lp ?: WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).also { lp = it }

            if (t.parent == null) w.addView(t, p)
            if (!dragging) dock()
        } catch (_: Throwable) { }
    }

    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0

    private fun onDrag(v: View, e: MotionEvent): Boolean {
        val p = lp ?: return false
        val w = wm ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                snap?.cancel()
                dragging = true
                val s = screen()
                // switch to absolute coordinates while dragging
                val left = if (side() == 1) s.x - chipSize(v as TextView).x else 0
                p.gravity = Gravity.TOP or Gravity.START
                p.x = left
                w.updateViewLayout(v, p)
                downRawX = e.rawX; downRawY = e.rawY
                startX = p.x; startY = p.y
            }
            MotionEvent.ACTION_MOVE -> {
                val s = screen()
                val c = chipSize(v as TextView)
                p.x = (startX + (e.rawX - downRawX)).toInt().coerceIn(0, (s.x - c.x).coerceAtLeast(0))
                p.y = (startY + (e.rawY - downRawY)).toInt().coerceIn(0, (s.y - c.y).coerceAtLeast(0))
                w.updateViewLayout(v, p)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val s = screen()
                val c = chipSize(v as TextView)
                val toRight = p.x + c.x / 2 > s.x / 2
                val targetX = if (toRight) s.x - c.x else 0
                prefs.edit()
                    .putInt("fps_side", if (toRight) 1 else 0)
                    .putFloat("fps_y", p.y.toFloat() / s.y)
                    .apply()
                snap = ValueAnimator.ofInt(p.x, targetX).apply {
                    duration = 180
                    addUpdateListener {
                        p.x = it.animatedValue as Int
                        try { w.updateViewLayout(v, p) } catch (_: Throwable) { }
                    }
                    addListener(object : android.animation.AnimatorListenerAdapter() {
                        override fun onAnimationEnd(a: android.animation.Animator) {
                            dragging = false
                            dock()
                        }
                    })
                    start()
                }
            }
        }
        return true
    }

    // ───────── measuring (SurfaceFlinger TimeStats) ─────────

    private fun loop() {
        // start recording; stats are cleared on every read so each reading is a fresh window
        Shell.run("dumpsys SurfaceFlinger --timestats -enable; dumpsys SurfaceFlinger --timestats -clear")
        var fg = ""
        var fgAt = 0L
        while (alive) {
            val ms = FPS_MS[prefs.getInt("fps_rate", 1).coerceIn(0, 2)]
            try { Thread.sleep(ms) } catch (_: InterruptedException) { break }
            val text: String
            if (!Shell.granted()) {
                text = "Shizuku?"
            } else {
                val now = System.currentTimeMillis()
                if (fg.isEmpty() || now - fgAt > 2000L) {
                    fg = foregroundPkg()
                    fgAt = now
                }
                val out = Shell.run(
                    "dumpsys SurfaceFlinger --timestats -dump; dumpsys SurfaceFlinger --timestats -clear"
                ).second
                val fps = if (fg.isEmpty()) null else parseFps(out, fg)
                text = if (fps == null) "Idle" else "${capToDisplay(fps)} FPS"
            }
            ui.post { tv?.text = text }
        }
    }

    @Suppress("DEPRECATION")
    private fun capToDisplay(fps: Double): Int {
        val v = Math.round(fps).toInt()
        val hz = try { Math.round(wm?.defaultDisplay?.refreshRate ?: 0f) } catch (_: Throwable) { 0 }
        return if (hz > 0 && v > hz) hz else v
    }

    private fun foregroundPkg(): String {
        val out = Shell.run("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'").second
        val m = Regex("mCurrentFocus=.*? ([A-Za-z0-9._]+)/").find(out)
            ?: Regex("mFocusedApp=.*? ([A-Za-z0-9._]+)/").find(out)
        return m?.groupValues?.get(1).orEmpty()
    }

    private class Layer(val name: String) {
        var total = 0.0
        var fps = 0.0
    }

    /**
     * Reads the TimeStats dump and returns `averageFPS` of the foreground app's layer.
     * Layers are matched by name (packageName is empty on some devices); SurfaceView (BLAST)
     * layers win, then the layer with the most frames. Returns null when there is no data.
     */
    private fun parseFps(out: String, pkg: String): Double? {
        val layers = ArrayList<Layer>()
        var cur: Layer? = null
        for (raw in out.lineSequence()) {
            val line = raw.trim()
            val eq = line.indexOf('=')
            if (eq < 0) continue
            val key = line.substring(0, eq).trim()
            val value = line.substring(eq + 1).trim()
            when (key) {
                "layerName" -> { cur = Layer(value); layers.add(cur) }
                "totalFrames" -> cur?.total = value.toDoubleOrNull() ?: 0.0
                "averageFPS" -> cur?.fps = value.toDoubleOrNull() ?: 0.0
            }
        }
        val mine = layers.filter { it.name.contains(pkg) }
        val views = mine.filter { it.name.startsWith("SurfaceView") && it.name.contains("BLAST") }
        val best = (if (views.isNotEmpty()) views else mine).maxByOrNull { it.total } ?: return null
        return if (best.total <= 0.0 || best.fps <= 0.0) null else best.fps
    }

    companion object {
        const val ACTION_STOP = "com.lowgx.app.STOP_FPS"
        private const val CH = "fps"
        private const val ID = 7
    }
}
