package com.lowgx.app

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.lang.reflect.Method
import java.util.concurrent.Executors

data class Game(val label: String, val pkg: String)

object Shell {
    private val newProcessMethod: Method? by lazy {
        try {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }
        } catch (_: Throwable) {
            null
        }
    }

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun granted(): Boolean = running() && try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun run(cmd: String): Pair<Int, String> = try {
        val p: Process = if (granted() && newProcessMethod != null) {
            newProcessMethod!!.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        } else {
            Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        }
        val out = p.inputStream.bufferedReader().use { it.readText() } +
                p.errorStream.bufferedReader().use { it.readText() }
        p.waitFor()
        p.exitValue() to out
    } catch (e: Throwable) {
        -1 to (e.message ?: "error")
    }
}

private const val ANGLE_CMD = "ls -d /system/*/*angle* /vendor/*/*angle* 2>/dev/null"
// Reads the REAL state from the system (not from saved prefs).
private const val CHECK_CMD =
    "echo \"P=\$(settings get global angle_gl_driver_selection_pkgs)\";" +
    "echo \"V=\$(settings get global angle_gl_driver_selection_values)\";" +
    "echo \"F=\$(getprop debug.angle.feature_overrides_enabled)\""
private val LOD_RE = Regex("forceTextureLodOffset(\\d+)")
private val KNOWN = setOf("com.dts.freefireth", "com.dts.freefiremax")
private val PKG_OK = Regex("[A-Za-z0-9._]+")

private fun stopAll(pkgs: List<String>) = pkgs.joinToString("") { " && am force-stop $it" }

private fun applyCmd(pkgs: List<String>, pixel: Boolean, level: Int): String {
    val feat = (if (pixel) "forceNearestFiltering:" else "") +
            "disableAnisotropicFiltering:forceTextureLodOffset$level"
    return "settings put global angle_gl_driver_selection_pkgs ${pkgs.joinToString(",")}" +
            " && settings put global angle_gl_driver_selection_values ${pkgs.joinToString(",") { "angle" }}" +
            " && setprop debug.angle.feature_overrides_enabled $feat" + stopAll(pkgs)
}

private fun restoreCmd(pkgs: List<String>) =
    "settings delete global angle_gl_driver_selection_values" +
            " && settings delete global angle_gl_driver_selection_pkgs" +
            " && setprop debug.angle.feature_overrides_enabled \"\"" + stopAll(pkgs)

private class PickHolder(val root: LinearLayout, val name: TextView, val pkg: TextView, val check: CheckBox)
private class Row(val root: LinearLayout, val title: TextView, val sub: TextView)

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_FONT = 77

private val PRESETS = intArrayOf(
    0xFF7CB342.toInt(), 0xFF7E57C2.toInt(), 0xFF1E88E5.toInt(), 0xFF00897B.toInt(), 0xFFE53935.toInt(),
    0xFFFB8C00.toInt(), 0xFFD81B60.toInt(), 0xFFFDD835.toInt(), 0xFF00ACC1.toInt(), 0xFF8D6E63.toInt()
)

private val FONT_OPTIONS = listOf(
    "default" to "Default", "medium" to "Medium", "condensed" to "Condensed",
    "serif" to "Serif", "mono" to "Monospace", "casual" to "Casual", "cursive" to "Cursive"
)

class MainActivity : Activity() {
    private val io = Executors.newFixedThreadPool(2)
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    // ── state (home) ──
    private var games: List<Game> = emptyList()
    private var picked: Set<String> = emptySet()
    private var running = false
    private var granted = false
    private var angle: Boolean? = null
    private var applied = false
    private var pixel = false
    private var level = 1
    private var aPixel = false
    private var aLevel = 4
    private var aCount = 0
    private var busy = false
    private var checking = true

    // ── state (theme) ──
    private var tMode = 0                // 0 system, 1 light, 2 dark
    private var tDynamic = true
    private var tSeed = 0xFF7CB342.toInt()
    private var tAmoled = false
    private var tFont = "default"
    private var tFontName = ""

    // ── navigation ──
    private var page = 0                 // 0 home, 1 settings, 2 theme
    private lateinit var root: FrameLayout
    private lateinit var scroll: ScrollView
    private lateinit var nav: LinearLayout
    private val navItems = ArrayList<Triple<LinearLayout, ImageView, TextView>>()

    // ── palette & font ──
    private lateinit var pal: Palette
    private var tfN: Typeface = Typeface.DEFAULT
    private var tfB: Typeface = Typeface.DEFAULT_BOLD
    private val night: Boolean get() = pal.night
    private val cBg: Int get() = pal.bg
    private val cCard: Int get() = pal.card
    private val cAlt: Int get() = pal.alt
    private val cAccent: Int get() = pal.accent
    private val cOnAccent: Int get() = pal.onAccent
    private val cContainer: Int get() = pal.container
    private val cOnContainer: Int get() = pal.onContainer
    private val cText: Int get() = pal.text
    private val cSub: Int get() = pal.sub
    private val cErr: Int get() = pal.err
    private val cRipple: Int get() = pal.ripple

    // ── home views ──
    private lateinit var content: LinearLayout
    private lateinit var tvStatusTitle: TextView
    private lateinit var tvStatusSub: TextView
    private lateinit var tvShizuku: TextView
    private lateinit var btnAllow: TextView
    private lateinit var angleNote: View
    private lateinit var gamesCard: View
    private lateinit var tvGames: TextView
    private lateinit var tvTexSub: TextView
    private lateinit var options: LinearLayout
    private lateinit var segMode: Segments
    private lateinit var lvSlider: StepSlider
    private lateinit var tvLevel: TextView
    private lateinit var btnSave: TextView
    private lateinit var btnRestore: TextView

    private var lA: Shizuku.OnBinderReceivedListener? = null
    private var lB: Shizuku.OnBinderDeadListener? = null
    private var lC: Shizuku.OnRequestPermissionResultListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        if (showCrashIfAny()) return
        picked = prefs.getString("sel", "")!!.split(",").filter { it.isNotEmpty() }.toSet()
        applied = prefs.getBoolean("applied", false)
        pixel = prefs.getBoolean("pixel", false)
        level = prefs.getInt("level", 1)
        aPixel = pixel
        aLevel = level
        aCount = prefs.getInt("count", 0)

        loadTheme()
        loadFonts()
        initPalette()
        setContentView(buildRoot())
        applyBarAppearance()
        show(0, true)

        // About ditampilkan sekali saat pertama kali dibuka
        if (!prefs.getBoolean("info_seen", false)) {
            content.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    prefs.edit().putBoolean("info_seen", true).apply()
                    showAbout()
                }
            }, 600)
        }

        try {
            val a = Shizuku.OnBinderReceivedListener { refresh() }
            val b = Shizuku.OnBinderDeadListener { refresh() }
            val c = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
            lA = a; lB = b; lC = c
            Shizuku.addBinderReceivedListenerSticky(a)
            Shizuku.addBinderDeadListener(b)
            Shizuku.addRequestPermissionResultListener(c)
        } catch (_: Throwable) { }

        refresh()
        loadGames()
    }

    // Setiap masuk / kembali ke aplikasi: cocokkan dengan kondisi sistem yang sebenarnya.
    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) syncState()
    }

    override fun onDestroy() {
        try {
            lA?.let { Shizuku.removeBinderReceivedListener(it) }
            lB?.let { Shizuku.removeBinderDeadListener(it) }
            lC?.let { Shizuku.removeRequestPermissionResultListener(it) }
        } catch (_: Throwable) { }
        io.shutdown()
        super.onDestroy()
    }

    private fun installCrashLogger() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(android.util.Log.getStackTraceString(e)) } catch (_: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }

    /** Jika launch sebelumnya crash, tampilkan pesan errornya agar bisa dikirim. */
    private fun showCrashIfAny(): Boolean {
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) return false
        val trace = try { f.readText().take(6000) } catch (_: Throwable) { "?" }
        val tvTrace = TextView(this).apply {
            text = trace
            textSize = 11f
            setTextIsSelectable(true)
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val btn = TextView(this).apply {
            text = "Tutup dan coba lagi"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setOnClickListener { f.delete(); recreate() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(TextView(context).apply {
                text = "LowGX crash di launch sebelumnya. Screenshot layar ini dan kirim ke developer:"
                setTextColor(Color.YELLOW)
                setPadding(dp(16), dp(32), dp(16), dp(8))
            })
            addView(ScrollView(context).apply { addView(tvTrace) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
            addView(btn, LinearLayout.LayoutParams(MATCH, WRAP))
        })
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (page) {
            2 -> show(1, true)
            1 -> show(0, true)
            else -> super.onBackPressed()
        }
    }

    // ───────── data (home) ─────────

    @Suppress("DEPRECATION")
    private fun findGamesSync(): List<Game> {
        val pm = packageManager
        return pm.getInstalledApplications(0)
            .asSequence()
            .filter { it.packageName != packageName }
            .filter {
                it.category == ApplicationInfo.CATEGORY_GAME ||
                        (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || it.packageName in KNOWN
            }
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { Game(pm.getApplicationLabel(it).toString(), it.packageName) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    private fun loadGames() = io.execute {
        val g = findGamesSync()
        runOnUiThread { games = g; render(false) }
    }

    private fun refresh() {
        if (io.isShutdown) return
        io.execute {
            val r = Shell.running()
            val g = Shell.granted()
            runOnUiThread {
                running = r
                granted = g
                render(false)
                if (g && angle == null) cekAngle()
            }
        }
    }

    private fun syncState() {
        if (io.isShutdown || busy) return
        checking = true
        render(false)
        io.execute {
            val r = Shell.run(CHECK_CMD)
            val lines = r.second.lines()
            fun field(k: String) = lines.firstOrNull { it.startsWith("$k=") }?.substring(k.length + 1)?.trim()
            val p = field("P")
            val v = field("V")
            val f = field("F")
            runOnUiThread {
                if (isFinishing || isDestroyed || busy) return@runOnUiThread
                checking = false
                if (p == null || v == null || f == null) {
                    render(false)
                    return@runOnUiThread
                }
                val pkgs = p.split(",").map { it.trim() }
                    .filter { it.isNotEmpty() && it != "null" && PKG_OK.matches(it) }
                val active = pkgs.isNotEmpty() && v.contains("angle") && f.contains("forceTextureLodOffset")
                val ed = prefs.edit()
                if (active) {
                    val lv = LOD_RE.find(f)?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(1, 4) ?: level
                    val px = f.contains("forceNearestFiltering")
                    applied = true
                    pixel = px; level = lv
                    aPixel = px; aLevel = lv; aCount = pkgs.size
                    picked = pkgs.toSet()
                    ed.putBoolean("applied", true).putBoolean("pixel", px).putInt("level", lv)
                        .putInt("count", pkgs.size)
                        .putString("sel", pkgs.joinToString(",")).putString("pkgs", pkgs.joinToString(","))
                } else {
                    applied = false
                    ed.putBoolean("applied", false)
                }
                ed.apply()
                render(true)
            }
        }
    }

    private fun requestPerm() {
        try { Shizuku.requestPermission(1) } catch (_: Throwable) { }
    }

    private fun cekAngle() {
        if (!running) toast("Start Shizuku first")
        else if (!granted) requestPerm()
        else io.execute {
            val out = Shell.run(ANGLE_CMD).second
            runOnUiThread { angle = out.contains("lib"); render(false) }
        }
    }

    private fun jalankan(cmd: String, ok: () -> Unit) {
        if (!granted) { toast("Shizuku not ready"); return }
        busy = true
        render(false)
        io.execute {
            val r = Shell.run(cmd)
            runOnUiThread {
                busy = false
                if (r.first == 0) ok() else toast("Failed: ${r.second.take(80)}")
                render(true)
            }
        }
    }

    private fun restore() {
        val pkgs = prefs.getString("pkgs", "")!!.split(",").filter { PKG_OK.matches(it) }
        jalankan(restoreCmd(pkgs)) {
            applied = false
            prefs.edit().putBoolean("applied", false).apply()
            toast("Restored to default")
        }
    }

    private fun simpan() {
        val pkgs = picked.filter { PKG_OK.matches(it) }
        if (pkgs.isEmpty()) { toast("Select at least one game"); return }
        val px = pixel
        val lv = level
        jalankan(applyCmd(pkgs, px, lv)) {
            applied = true
            aPixel = px
            aLevel = lv
            aCount = pkgs.size
            prefs.edit().putBoolean("applied", true).putBoolean("pixel", px)
                .putInt("level", lv).putInt("count", pkgs.size)
                .putString("sel", pkgs.joinToString(",")).putString("pkgs", pkgs.joinToString(","))
                .apply()
            toast("Saved. Reopen the game")
        }
    }

    // ───────── render (home) ─────────

    private fun render(animate: Boolean) {
        if (page != 0) return
        if (animate) TransitionManager.beginDelayedTransition(content, AutoTransition().setDuration(200))

        tvStatusTitle.text = if (checking) "Checking…" else if (applied) "Active" else "Default"
        tvStatusSub.text = if (checking) "Syncing with system"
        else if (applied)
            "Level $aLevel · ${if (aPixel) "Pixel" else "Blur"} · $aCount game${if (aCount == 1) "" else "s"}"
        else "Original textures"

        tvShizuku.text = when {
            !running -> "Not running"
            !granted -> "Permission needed"
            else -> "Connected"
        }
        btnAllow.visibility = if (running && !granted) View.VISIBLE else View.GONE
        angleNote.visibility = if (angle == false) View.VISIBLE else View.GONE

        tvGames.text = if (picked.isEmpty()) "Tap to choose"
        else picked.joinToString(", ") { p -> games.firstOrNull { it.pkg == p }?.label ?: p }

        val unsupported = angle == false
        gamesCard.alpha = 1f
        val ready = picked.isNotEmpty() && !unsupported
        tvTexSub.text = when {
            unsupported -> "Not available on this device"
            ready -> "Reduce texture detail"
            else -> "Select a game first"
        }
        options.alpha = if (ready) 1f else 0.4f
        segMode.select(if (pixel) 1 else 0)
        lvSlider.isEnabled = ready
        lvSlider.index = level - 1
        tvLevel.text = "$level · " + when (level) { 1 -> "Light"; 2 -> "Medium"; 3 -> "Strong"; else -> "Lowest" }

        val canSave = ready && !busy
        btnSave.isEnabled = canSave
        btnSave.alpha = if (canSave) 1f else 0.4f
        btnSave.text = if (busy) "Saving…" else "Save changes"
        btnRestore.visibility = if (applied && !checking) View.VISIBLE else View.GONE
        btnRestore.isEnabled = !busy

    }

    // ───────── theme store ─────────

    private fun loadTheme() {
        tMode = prefs.getInt("t_mode", 0)
        tDynamic = prefs.getBoolean("t_dyn", Build.VERSION.SDK_INT >= 31)
        if (Build.VERSION.SDK_INT < 31) tDynamic = false
        tSeed = prefs.getInt("t_seed", 0xFF7CB342.toInt())
        tAmoled = prefs.getBoolean("t_amoled", false)
        tFont = prefs.getString("t_font", "default")!!
        tFontName = prefs.getString("t_fontname", "")!!
    }

    private fun saveTheme() {
        prefs.edit().putInt("t_mode", tMode).putBoolean("t_dyn", tDynamic).putInt("t_seed", tSeed)
            .putBoolean("t_amoled", tAmoled).putString("t_font", tFont).putString("t_fontname", tFontName)
            .apply()
    }

    private fun resetTheme() {
        prefs.edit().remove("t_mode").remove("t_dyn").remove("t_seed").remove("t_amoled")
            .remove("t_font").remove("t_fontname").apply()
        File(filesDir, "custom_font").delete()
        loadTheme()
        loadFonts()
        restyle()
        toast("Appearance reset")
    }

    private fun faceFor(key: String): Typeface = when (key) {
        "medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        "serif" -> Typeface.SERIF
        "mono" -> Typeface.MONOSPACE
        "casual" -> Typeface.create("casual", Typeface.NORMAL)
        "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
        "custom" -> try {
            Typeface.Builder(File(filesDir, "custom_font")).build() ?: Typeface.DEFAULT
        } catch (_: Throwable) { Typeface.DEFAULT }
        else -> Typeface.DEFAULT
    }

    private fun loadFonts() {
        if (tFont == "custom" && !File(filesDir, "custom_font").exists()) tFont = "default"
        tfN = faceFor(tFont)
        tfB = Typeface.create(tfN, Typeface.BOLD)
    }

    private fun systemNight() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun effectiveDark() = when (tMode) { 1 -> false; 2 -> true; else -> systemNight() }

    private fun initPalette() {
        pal = Themes.build(this, tDynamic, tSeed, effectiveDark(), tAmoled)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        window.setBackgroundDrawable(ColorDrawable(cBg))
    }

    /** Dipanggil SETELAH setContentView (decor view baru siap). */
    private fun applyBarAppearance() {
        try {
            val light = !pal.night
        if (Build.VERSION.SDK_INT >= 30) {
            val m = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (light) m else 0, m)
        } else {
            @Suppress("DEPRECATION")
            run {
                val m = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                val d = window.decorView
                d.systemUiVisibility = if (light) d.systemUiVisibility or m else d.systemUiVisibility and m.inv()
            }
        }
            } catch (_: Throwable) { }
    }

    /** Bangun ulang seluruh UI dengan palet/font baru, tetap di halaman yang sama. */
    private fun restyle() {
        val sy = scroll.scrollY
        initPalette()
        setContentView(buildRoot())
        applyBarAppearance()
        show(page, false)
        scroll.post { scroll.scrollTo(0, sy) }
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(170).start()
    }

    // ───────── helpers ─────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun shape(color: Int, radii: FloatArray) = GradientDrawable().apply {
        setColor(color)
        cornerRadii = radii
    }

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun ripple(content: android.graphics.drawable.Drawable?, r: Int) =
        RippleDrawable(ColorStateList.valueOf(cRipple), content, rounded(Color.WHITE, r))

    private fun tv(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(color)
        typeface = if (bold) tfB else tfN
    }

    private fun subText() = tv(14f, cSub).apply {
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun card(bg: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(bg, 20)
    }

    private fun lp(bottom: Int = 12) = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(bottom) }
    private fun lpx(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun item(title: String, sub: TextView, trailing: View?): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val col = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(16f, cText).apply { text = title })
                addView(sub)
            }
            addView(col, lpx(0, WRAP).apply { weight = 1f })
            if (trailing != null) {
                addView(trailing, lpx(WRAP, WRAP).apply { leftMargin = dp(12) })
            }
        }

    private fun smallButton(text: String, onClick: () -> Unit) = tv(14f, cOnContainer, true).apply {
        this.text = text
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(8), dp(16), dp(8))
        background = ripple(rounded(cContainer, 20), 20)
        setOnClickListener { onClick() }
        bounce()
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit) =
        tv(16f, if (filled) cOnAccent else cErr, true).apply {
            this.text = text
            gravity = Gravity.CENTER
            background = if (filled) ripple(rounded(cAccent, 26), 26)
            else ripple(GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), cErr)
                cornerRadius = dp(26).toFloat()
            }, 26)
            setOnClickListener { onClick() }
            bounce()
        }

    @Suppress("ClickableViewAccessibility")
    private fun View.bounce() {
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(110).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
    }

    private inner class Segments(
        labels: List<String>,
        private val h: Int = 40,
        private val onPick: (Int) -> Unit
    ) {
        val view = LinearLayout(this@MainActivity)
        private val items = ArrayList<TextView>()

        init {
            view.orientation = LinearLayout.HORIZONTAL
            labels.forEachIndexed { i, l ->
                val t = tv(14f, cText, true).apply {
                    text = l
                    gravity = Gravity.CENTER
                    setOnClickListener { onPick(i) }
                }
                items.add(t)
                view.addView(t, lpx(0, dp(h)).apply {
                    weight = 1f
                    if (i > 0) leftMargin = dp(4)
                })
            }
        }

        fun select(i: Int) {
            items.forEachIndexed { k, t ->
                val on = k == i
                t.background = rounded(if (on) cAccent else cAlt, h / 2)
                t.setTextColor(if (on) cOnAccent else cText)
            }
        }
    }

    // ───────── shell: root + nav + paging ─────────

    private fun buildRoot(): View {
        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(0, 0, 0, dp(104))
        }
        nav = buildNav()
        root = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(nav, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = dp(16) })
        }
        return root
    }

    private fun navIndex() = if (page == 0) 0 else 1

    private fun buildNav(): LinearLayout {
        navItems.clear()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(pal.accent, 34)
            elevation = dp(6).toFloat()
        }
        val defs = listOf(Triple(R.drawable.ic_home, "Home", 0), Triple(R.drawable.ic_settings, "Settings", 1))
        for ((icon, label, idx) in defs) {
            val iv = ImageView(this).apply { setImageResource(icon) }
            val t = tv(16f, pal.navSelContent, true).apply {
                text = label
                setPadding(dp(8), 0, 0, 0)
            }
            val btn = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(13), dp(20), dp(13))
                addView(iv, lpx(dp(24), dp(24)))
                addView(t)
                setOnClickListener { if (navIndex() != idx) show(idx, true) }
                bounce()
            }
            navItems.add(Triple(btn, iv, t))
            bar.addView(btn)
        }
        return bar
    }

    private fun updateNav(anim: Boolean) {
        if (anim) TransitionManager.beginDelayedTransition(nav, AutoTransition().setDuration(220))
        val sel = navIndex()
        navItems.forEachIndexed { i, (item, iv, t) ->
            val on = i == sel
            item.background = if (on) rounded(pal.navSel, 26) else null
            iv.imageTintList = ColorStateList.valueOf(if (on) pal.navSelContent else pal.onAccent)
            t.visibility = if (on) View.VISIBLE else View.GONE
        }
    }

    private fun show(p: Int, anim: Boolean) {
        page = p
        val v = when (p) { 0 -> buildHome(); 1 -> buildSettings(); else -> buildTheme() }
        scroll.removeAllViews()
        scroll.addView(v)
        scroll.scrollTo(0, 0)
        if (p == 0) render(false)
        updateNav(anim)
        if (anim) playEntrance(v)
    }

    private fun playEntrance(v: ViewGroup) {
        for (i in 0 until v.childCount) {
            val c = v.getChildAt(i)
            c.alpha = 0f
            c.translationY = dp(36).toFloat()
            c.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 45L).setDuration(380)
                .setInterpolator(DecelerateInterpolator())
                .withLayer().start()
        }
    }

    private fun pageLayout() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(8), dp(16), dp(24))
    }

    private fun bigTitle(t: String) = tv(40f, cText, true).apply {
        text = t
        setPadding(dp(8), dp(28), 0, dp(12))
    }

    private fun section(t: String) = tv(16f, cAccent, true).apply {
        text = t
        setPadding(dp(8), dp(20), 0, dp(10))
    }

    private fun badge(icon: Int) = ImageView(this).apply {
        setImageResource(icon)
        imageTintList = ColorStateList.valueOf(cOnContainer)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = circle(cContainer)
    }

    private fun chevron() = ImageView(this).apply {
        setImageResource(R.drawable.ic_chevron)
        imageTintList = ColorStateList.valueOf(cSub)
    }

    private fun row(icon: Int?, title: String, sub: String?, trailing: View?, onClick: (() -> Unit)?): Row {
        val t = tv(17f, cText, true).apply { text = title }
        val s = subText().apply { if (sub == null) visibility = View.GONE else text = sub }
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            minimumHeight = dp(76)
            if (icon != null) addView(badge(icon), lpx(dp(48), dp(48)).apply { rightMargin = dp(16) })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(t)
                addView(s)
            }, lpx(0, WRAP).apply { weight = 1f })
            if (trailing != null) {
                val tl = (trailing.layoutParams as? LinearLayout.LayoutParams) ?: lpx(WRAP, WRAP)
                tl.leftMargin = dp(12)
                addView(trailing, tl)
            }
            if (onClick != null) {
                isClickable = true
                setOnClickListener { onClick() }
            }
        }
        return Row(r, t, s)
    }

    /** Kelompok kartu bersambung ala akiHz: sudut luar besar, sudut dalam kecil. */
    private fun group(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val big = dp(28).toFloat()
        val small = dp(8).toFloat()
        views.forEachIndexed { i, v ->
            val top = if (i == 0) big else small
            val bot = if (i == views.size - 1) big else small
            val radii = floatArrayOf(top, top, top, top, bot, bot, bot, bot)
            v.background = RippleDrawable(
                ColorStateList.valueOf(cRipple), shape(cCard, radii), shape(Color.WHITE, radii)
            )
            addView(v, lpx(MATCH, WRAP).apply { if (i > 0) topMargin = dp(4) })
        }
    }

    // ───────── page: HOME (texture) ─────────

    private fun buildHome(): LinearLayout {
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        // title (tanpa tombol About — dipindah ke Settings)
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_launcher_foreground)
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = rounded(getColor(R.color.ic_launcher_background), 14)
            }, lpx(dp(52), dp(52)).apply { rightMargin = dp(14) })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(30f, cText, true).apply { text = "LowGX" })
                addView(tv(14f, cSub).apply { text = "Graphics optimizer for any games" })
            }, lpx(0, WRAP).apply { weight = 1f })
        }, lp())

        // status
        tvStatusTitle = tv(22f, cOnContainer, true)
        tvStatusSub = tv(14f, cOnContainer)
        content.addView(card(cContainer).apply {
            setPadding(dp(20), dp(20), dp(20), dp(20))
            addView(tvStatusTitle)
            addView(tvStatusSub)
        }, lp())

        // system
        tvShizuku = subText()
        btnAllow = smallButton("Allow") { requestPerm() }
        content.addView(card(cCard).apply {
            addView(item("Shizuku", tvShizuku, btnAllow))
            angleNote = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(pal.errBg, 16)
                addView(ImageView(context).apply {
                    setImageResource(R.drawable.ic_info)
                    imageTintList = ColorStateList.valueOf(cErr)
                }, lpx(dp(24), dp(24)).apply { rightMargin = dp(12) })
                addView(tv(14f, pal.onErrBg).apply {
                    text = "This device does not support ANGLE. The features in this app will not work."
                    setLineSpacing(0f, 1.1f)
                }, lpx(0, WRAP).apply { weight = 1f })
                visibility = View.GONE
            }
            addView(angleNote, lpx(MATCH, WRAP).apply {
                leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(12)
            })
        }, lp())

        // games
        tvGames = subText()
        gamesCard = card(cCard).apply {
            addView(item("Select games", tvGames, null))
            foreground = ripple(null, 20)
            isClickable = true
            setOnClickListener {
                showPicker()
            }
            bounce()
        }
        content.addView(gamesCard, lp())

        // texture
        tvTexSub = subText()
        val texRow = item("Low Texture", tvTexSub, null)
        segMode = Segments(listOf("Blur", "Pixel")) {
            if (angle == false) toast("ANGLE is not supported on this device")
            else if (picked.isEmpty()) toast("Select a game first") else { pixel = it == 1; render(false) }
        }
        lvSlider = StepSlider(this).apply {
            steps = 4
            trackColor = cBg
            fillColor = cAccent
            thumbColor = cAccent
            index = 0
            onChange = { i ->
                if (angle == false) toast("ANGLE is not supported on this device")
                else if (picked.isNotEmpty()) { level = i + 1; render(false) }
            }
        }
        tvLevel = tv(16f, cAccent, true)
        options = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(16))
            addView(segMode.view)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(16), 0, dp(8))
                addView(tv(16f, cText, true).apply { text = "Texture level" }, lpx(0, WRAP).apply { weight = 1f })
                addView(tvLevel)
            })
            addView(lvSlider, lpx(MATCH, WRAP))
            addView(tv(12f, cSub).apply {
                text = "Higher number = lower graphics quality and better performance."
                setPadding(0, dp(10), 0, 0)
            })
        }
        content.addView(card(cCard).apply {
            addView(texRow)
            addView(options)
        }, lp())

        // actions
        btnSave = button("Save changes", true) { if (!busy) simpan() }
        btnRestore = button("Restore default", false) { if (!busy) restore() }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(btnSave, lpx(MATCH, dp(52)))
            addView(btnRestore, lpx(MATCH, dp(52)).apply { topMargin = dp(8) })
        }, lp(0))

        return content
    }

    // ───────── page: SETTINGS ─────────

    private fun buildSettings(): LinearLayout {
        val l = pageLayout()
        l.addView(bigTitle("Settings"), lp(4))

        l.addView(section("Appearance"))
        val seg = Segments(listOf("System", "Light", "Dark"), 48) { i ->
            if (i != tMode) { tMode = i; saveTheme(); restyle() }
        }
        seg.select(tMode)
        val modeCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(tv(17f, cText, true).apply { text = "Color mode" })
            addView(seg.view, lpx(MATCH, dp(48)).apply { topMargin = dp(12) })
        }
        val themeRow = row(R.drawable.ic_palette, "Theme", "Colors, fonts and AMOLED", chevron()) { show(2, true) }
        val resetRow = row(R.drawable.ic_reset, "Reset appearance", "Restore default colors and font", null) { resetTheme() }
        l.addView(group(modeCard, themeRow.root, resetRow.root), lp(0))

        l.addView(section("About"))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "" }
        val aboutRow = row(R.drawable.ic_info, "About LowGX", "Version $ver · how to use", chevron()) { showAbout() }
        l.addView(group(aboutRow.root), lp(0))
        return l
    }

    // ───────── page: THEME ─────────

    private fun buildTheme(): LinearLayout {
        val l = pageLayout()

        // header
        l.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(20), 0, dp(12))
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_back)
                imageTintList = ColorStateList.valueOf(cOnContainer)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = ripple(circle(cContainer), 24)
                contentDescription = "Back"
                setOnClickListener { show(1, true) }
                bounce()
            }, lpx(dp(48), dp(48)).apply { rightMargin = dp(14) })
            addView(tv(32f, cText, true).apply { text = "Theme" })
        }, lp(4))

        // preview
        l.addView(buildPreview(), lp(4))

        // ── color ──
        l.addView(section("Color"))
        val canDyn = Build.VERSION.SDK_INT >= 31
        val srcSeg = Segments(listOf("Dynamic", "Custom"), 48) { i ->
            if (i == 0 && !canDyn) toast("Dynamic color needs Android 12 or newer")
            else if ((i == 0) != tDynamic) { tDynamic = i == 0; saveTheme(); restyle() }
        }
        srcSeg.select(if (tDynamic) 0 else 1)
        val srcCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(tv(17f, cText, true).apply { text = "Color source" })
            addView(subText().apply {
                text = when {
                    !canDyn -> "Dynamic color needs Android 12 or newer."
                    tDynamic -> "Follows your wallpaper colors."
                    else -> "Uses the color you choose below."
                }
                setPadding(0, dp(2), 0, 0)
            })
            addView(srcSeg.view, lpx(MATCH, dp(48)).apply { topMargin = dp(12) })
        }
        val colorViews = ArrayList<View>()
        colorViews.add(srcCard)

        if (!tDynamic) {
            val palCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(16), dp(12), dp(12))
                addView(tv(17f, cText, true).apply { text = "Palette"; setPadding(dp(4), 0, 0, dp(8)) })
                for (r in 0 until 2) {
                    addView(LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        for (c in 0 until 5) addView(swatch(PRESETS[r * 5 + c]), lpx(0, dp(52)).apply { weight = 1f })
                    })
                }
            }
            colorViews.add(palCard)
            val hexTxt = String.format("#%06X", tSeed and 0xFFFFFF)
            val dot = View(this).apply {
                background = circle(tSeed)
                layoutParams = lpx(dp(32), dp(32))
            }
            val pickRow = row(R.drawable.ic_drop, "Color picker", hexTxt, dot) { showColorPicker() }
            colorViews.add(pickRow.root)
        }

        val tg = Toggle(this, pal.accent, pal.alt, cSub, pal.onAccent, cSub)
        tg.set(tAmoled, false)
        val amoledRow = row(R.drawable.ic_contrast, "AMOLED black",
            "Pure black background in dark mode", tg) {
            tAmoled = !tAmoled
            tg.set(tAmoled, true)
            saveTheme()
            tg.postDelayed({ if (!isFinishing && !isDestroyed) restyle() }, 190)
        }
        colorViews.add(amoledRow.root)
        l.addView(group(*colorViews.toTypedArray()), lp(0))

        // ── font ──
        l.addView(section("Font"))
        val fontRows = ArrayList<View>()
        val opts = ArrayList(FONT_OPTIONS)
        if (File(filesDir, "custom_font").exists()) opts.add("custom" to "Custom")
        for ((key, label) in opts) {
            val sel = tFont == key
            val trailing = if (sel) ImageView(this).apply {
                setImageResource(R.drawable.ic_check)
                imageTintList = ColorStateList.valueOf(cAccent)
            } else null
            val sub = if (key == "custom") tFontName.ifEmpty { "Imported font" } else null
            val r = row(null, label, sub, trailing) {
                if (tFont != key) {
                    tFont = key
                    saveTheme()
                    loadFonts()
                    restyle()
                }
            }
            r.title.typeface = Typeface.create(faceFor(key), Typeface.BOLD)
            r.title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            fontRows.add(r.root)
        }
        val importRow = row(R.drawable.ic_font, "Import font", "Choose a .ttf or .otf file", chevron()) { pickFont() }
        fontRows.add(importRow.root)
        l.addView(group(*fontRows.toTypedArray()), lp(0))
        return l
    }

    private fun swatch(color: Int): View {
        val sel = !tDynamic && (tSeed and 0xFFFFFF) == (color and 0xFFFFFF)
        return FrameLayout(this).apply {
            val dot = FrameLayout(context).apply {
                background = circle(color)
                if (sel) {
                    val lum = (Color.red(color) * 0.299 + Color.green(color) * 0.587 + Color.blue(color) * 0.114) / 255
                    addView(ImageView(context).apply {
                        setImageResource(R.drawable.ic_check)
                        imageTintList = ColorStateList.valueOf(if (lum > 0.6) Color.BLACK else Color.WHITE)
                        setPadding(dp(10), dp(10), dp(10), dp(10))
                    }, FrameLayout.LayoutParams(MATCH, MATCH))
                }
            }
            addView(dot, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
            isClickable = true
            setOnClickListener {
                tSeed = color
                tDynamic = false
                saveTheme()
                restyle()
            }
            dot.bounce()
        }
    }

    // ───────── preview ─────────

    private fun buildPreview(): View {
        val light = Themes.build(this, tDynamic, tSeed, false, false)
        val dark = Themes.build(this, tDynamic, tSeed, true, tAmoled)
        return card(cCard).apply {
            background = rounded(cCard, 28)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(tv(17f, cText, true).apply { text = "Preview" })
            addView(subText().apply { text = "Light and dark with your current colors and font." })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(12), 0, 0)
                addView(mock("Light", light), lpx(0, WRAP).apply { weight = 1f; rightMargin = dp(6) })
                addView(mock("Dark", dark), lpx(0, WRAP).apply { weight = 1f; leftMargin = dp(6) })
            })
        }
    }

    private fun mock(label: String, p: Palette): View {
        fun t(size: Float, color: Int, bold: Boolean, text: String) =
            tv(size, color, bold).apply { this.text = text; maxLines = 1 }
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(p.bg, 18)
            setPadding(dp(10), dp(12), dp(10), dp(10))
            addView(t(14f, p.text, true, "LowGX"))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(p.container, 12)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                addView(t(12f, p.onContainer, true, "Active"))
                addView(t(10f, p.onContainer, false, "Level 3 · Blur"))
            }, lpx(MATCH, WRAP).apply { topMargin = dp(8) })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(p.card, 12)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                addView(t(12f, p.text, true, "Select games"))
                addView(t(10f, p.sub, false, "Tap to choose"))
            }, lpx(MATCH, WRAP).apply { topMargin = dp(6) })
            addView(t(12f, p.onAccent, true, "Save").apply {
                gravity = Gravity.CENTER
                background = rounded(p.accent, 14)
                setPadding(0, dp(7), 0, dp(7))
            }, lpx(MATCH, WRAP).apply { topMargin = dp(8) })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                background = rounded(p.accent, 16)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                addView(View(context).apply { background = rounded(p.navSel, 12) }, lpx(dp(34), dp(18)))
                addView(View(context).apply { background = rounded(p.onAccent, 6) }, lpx(dp(12), dp(12)).apply { leftMargin = dp(10); rightMargin = dp(8) })
            }, lpx(WRAP, WRAP).apply { topMargin = dp(10); gravity = Gravity.CENTER_HORIZONTAL })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(screen, lpx(MATCH, WRAP))
            addView(tv(12f, cSub, true).apply {
                text = label
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            }, lpx(MATCH, WRAP))
        }
    }

    // ───────── dialogs ─────────

    private fun sheet(
        title: String?, body: View,
        positive: String?, onPositive: (() -> Unit)? = null,
        negative: String? = null
    ): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        fun textBtn(t: String, click: () -> Unit) = tv(15f, cAccent, true).apply {
            text = t
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = ripple(null, 20)
            setOnClickListener { click() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cCard, 28)
            setPadding(dp(24), dp(24), dp(24), dp(12))
            if (title != null) addView(tv(22f, cText, true).apply {
                text = title
                setPadding(0, 0, 0, dp(12))
            })
            addView(body, lpx(MATCH, WRAP))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                if (negative != null) addView(textBtn(negative) { d.dismiss() })
                if (positive != null) addView(textBtn(positive) { d.dismiss(); onPositive?.invoke() })
            }, lpx(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        d.setContentView(FrameLayout(this).apply {
            setPadding(dp(20), 0, dp(20), 0)
            addView(card, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
        })
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(MATCH, WRAP)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        d.show()
        return d
    }

    private fun input(hint: String) = EditText(this).apply {
        this.hint = hint
        isSingleLine = true
        typeface = tfN
        setTextColor(cText)
        setHintTextColor(cSub)
        background = rounded(cAlt, 16)
        setPadding(dp(16), dp(12), dp(16), dp(12))
    }

    private fun showAbout() {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "" }

        fun heading(t: String) = tv(14f, cText, true).apply { text = t }
        fun body(t: String) = tv(14f, cSub).apply {
            text = t
            setLineSpacing(0f, 1.15f)
            setPadding(0, dp(6), 0, dp(14))
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(16))
                addView(ImageView(context).apply {
                    setImageResource(R.drawable.ic_launcher_foreground)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    background = rounded(getColor(R.color.ic_launcher_background), 14)
                }, lpx(dp(48), dp(48)).apply { rightMargin = dp(14) })
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(tv(20f, cText, true).apply { text = "LowGX" })
                    addView(tv(12f, cSub).apply { text = "Version $ver" })
                })
            })
            addView(heading("About"))
            addView(body(
                "LowGX reduces texture detail in the games you choose, helping them run " +
                        "smoother on low-end devices. It works through the system ANGLE graphics " +
                        "driver and requires Shizuku. " +
                        "This application was created by Claude AI so you can rename it however you like."
            ))
            addView(heading("How to use"))
            addView(body(
                "1. Start Shizuku and allow access.\n" +
                        "2. Select your games.\n" +
                        "3. Choose a mode and a texture level.\n" +
                        "4. Save, then reopen the game."
            ))
            addView(heading("Texture level"))
            addView(body(
                "Levels 1 to 4 set how much texture detail is removed. The higher the number, " +
                        "the lower the graphics quality and the lighter the game runs. " +
                        "Level 1 is a light reduction, level 4 is the lowest quality for maximum performance."
            ))
            addView(heading("Good to know"))
            addView(body(
                "Blur softens textures, Pixel makes them blocky for a bigger boost. " +
                        "Changes only affect the selected games and can be undone anytime with Restore default."
            ))
        }
        val maxH = (resources.displayMetrics.heightPixels * 0.55f).toInt()
        sheet(null, MaxHeightScroll(this, maxH).apply { addView(box) }, "Got it")
    }

    // ───────── color picker ─────────

    private fun showColorPicker() {
        val hsv = FloatArray(3)
        Color.colorToHSV(tSeed, hsv)
        var cur = tSeed
        var updating = false

        val sv = SatValView(this).apply { hue = hsv[0]; sat = hsv[1]; value = hsv[2] }
        val hueBar = HueBar(this).apply { hue = hsv[0] }
        val dot = View(this).apply { background = circle(cur) }
        val hex = input("#RRGGBB").apply {
            setText(String.format("#%06X", cur and 0xFFFFFF))
            filters = arrayOf(android.text.InputFilter.LengthFilter(7))
        }

        fun refresh(fromHex: Boolean) {
            cur = Color.HSVToColor(floatArrayOf(sv.hue, sv.sat, sv.value))
            dot.background = circle(cur)
            if (!fromHex) {
                updating = true
                hex.setText(String.format("#%06X", cur and 0xFFFFFF))
                updating = false
            }
        }
        sv.onChange = { refresh(false) }
        hueBar.onChange = { sv.hue = hueBar.hue; sv.invalidate(); refresh(false) }
        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val t = s?.toString()?.trim()?.removePrefix("#") ?: return
                if (t.length != 6) return
                val c = try { Color.parseColor("#$t") } catch (_: Throwable) { return }
                val h = FloatArray(3)
                Color.colorToHSV(c, h)
                sv.hue = h[0]; sv.sat = h[1]; sv.value = h[2]
                hueBar.hue = h[0]
                sv.invalidate(); hueBar.invalidate()
                refresh(true)
            }
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(sv, lpx(MATCH, dp(190)))
            addView(hueBar, lpx(MATCH, dp(40)).apply { topMargin = dp(10) })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(dot, lpx(dp(40), dp(40)).apply { rightMargin = dp(12) })
                addView(hex, lpx(0, WRAP).apply { weight = 1f })
            }, lpx(MATCH, WRAP).apply { topMargin = dp(10) })
        }
        sheet("Color picker", box, "Apply", {
            tSeed = cur or 0xFF000000.toInt()
            tDynamic = false
            saveTheme()
            restyle()
        }, "Cancel")
    }

    // ───────── custom font import ─────────

    private fun pickFont() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(i, REQ_FONT) } catch (_: Throwable) { toast("No file picker found") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FONT || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (io.isShutdown) return
        io.execute {
            val ok = importFont(uri)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (ok) {
                    loadFonts()
                    restyle()
                    toast("Font applied")
                } else toast("Not a valid font file")
            }
        }
    }

    private fun importFont(uri: Uri): Boolean = try {
        val tmp = File(filesDir, "font.tmp")
        var total = 0L
        contentResolver.openInputStream(uri)?.use { ins ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > 12L * 1024 * 1024) throw IllegalStateException("too big")
                    out.write(buf, 0, n)
                }
            }
        } ?: throw IllegalStateException("no stream")
        if (Typeface.Builder(tmp).build() == null) { tmp.delete(); false }
        else {
            var name = ""
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: ""
            }
            val dest = File(filesDir, "custom_font")
            dest.delete()
            tmp.renameTo(dest)
            tFont = "custom"
            tFontName = name
            saveTheme()
            true
        }
    } catch (_: Throwable) {
        File(filesDir, "font.tmp").delete()
        false
    }

    // ───────── game picker ─────────

    private fun newPickRow(): PickHolder {
        val name = tv(16f, cText).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val pkg = tv(12f, cSub).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val check = CheckBox(this).apply {
            isClickable = false
            isFocusable = false
            buttonTintList = ColorStateList.valueOf(cAccent)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(name)
                addView(pkg)
            }, lpx(0, WRAP).apply { weight = 1f })
            addView(check)
        }
        return PickHolder(root, name, pkg, check)
    }

    private fun showPicker() {
        val list = ArrayList<Game>(games)
        val adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int) = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val h: PickHolder
                if (convertView == null) {
                    h = newPickRow()
                    h.root.tag = h
                } else {
                    h = convertView.tag as PickHolder
                }
                val g = list[position]
                h.name.text = g.label
                h.pkg.text = g.pkg
                h.check.isChecked = g.pkg in picked
                return h.root
            }
        }

        val search = input("Search games")
        val empty = tv(14f, cSub).apply {
            text = if (games.isEmpty()) "No games found" else "No match"
            setPadding(0, dp(24), 0, dp(24))
        }
        val lv = ListView(this).apply {
            divider = null
            this.adapter = adapter
            emptyView = empty
            setOnItemClickListener { _, _, pos, _ ->
                val pkg = list[pos].pkg
                picked = if (pkg in picked) picked - pkg else picked + pkg
                adapter.notifyDataSetChanged()
                render(true)
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val key = s?.toString()?.trim().orEmpty()
                list.clear()
                list.addAll(
                    if (key.isEmpty()) games
                    else games.filter { it.label.contains(key, true) || it.pkg.contains(key, true) }
                )
                adapter.notifyDataSetChanged()
            }
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(search, lpx(MATCH, WRAP))
            addView(lv, lpx(MATCH, dp(320)).apply { topMargin = dp(8) })
            addView(empty)
        }
        sheet("Select games", box, "Done")
    }
}
