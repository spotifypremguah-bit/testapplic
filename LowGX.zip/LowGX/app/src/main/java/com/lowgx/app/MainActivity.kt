package com.lowgx.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.lang.reflect.Method
import java.util.concurrent.Executors

data class Game(val label: String, val pkg: String)

object Shell {
    private val newProcessMethod: Method? by lazy {
        try {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }
        } catch (_: Throwable) {
            null
        }
    }

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun granted(): Boolean = running() && try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun run(cmd: String): Pair<Int, String> = try {
        val p: Process = if (granted() && newProcessMethod != null) {
            newProcessMethod!!.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        } else {
            Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        }
        val out = p.inputStream.bufferedReader().use { it.readText() } +
                p.errorStream.bufferedReader().use { it.readText() }
        p.waitFor()
        p.exitValue() to out
    } catch (e: Throwable) {
        -1 to (e.message ?: "error")
    }
}

private const val ANGLE_CMD = "ls -d /system/*/*angle* /vendor/*/*angle* 2>/dev/null"
private val KNOWN = setOf("com.dts.freefireth", "com.dts.freefiremax")
private val PKG_OK = Regex("[A-Za-z0-9._]+")

private fun stopAll(pkgs: List<String>) = pkgs.joinToString("") { " && am force-stop $it" }

private fun applyCmd(pkgs: List<String>, pixel: Boolean, level: Int): String {
    val feat = (if (pixel) "forceNearestFiltering:" else "") +
            "disableAnisotropicFiltering:forceTextureLodOffset$level"
    return "settings put global angle_gl_driver_selection_pkgs ${pkgs.joinToString(",")}" +
            " && settings put global angle_gl_driver_selection_values ${pkgs.joinToString(",") { "angle" }}" +
            " && setprop debug.angle.feature_overrides_enabled $feat" + stopAll(pkgs)
}

private fun restoreCmd(pkgs: List<String>) =
    "settings delete global angle_gl_driver_selection_values" +
            " && settings delete global angle_gl_driver_selection_pkgs" +
            " && setprop debug.angle.feature_overrides_enabled \"\"" + stopAll(pkgs)

private class PickHolder(val root: LinearLayout, val name: TextView, val pkg: TextView, val check: CheckBox)

class MainActivity : Activity() {
    private val io = Executors.newFixedThreadPool(2)
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    // state
    private var games: List<Game> = emptyList()
    private var picked: Set<String> = emptySet()
    private var running = false
    private var granted = false
    private var angle: Boolean? = null
    private var applied = false
    private var pixel = false
    private var level = 4
    private var aPixel = false
    private var aLevel = 4
    private var aCount = 0
    private var busy = false

    // palette
    private var night = false
    private var cBg = 0
    private var cCard = 0
    private var cAccent = 0
    private var cOnAccent = 0
    private var cContainer = 0
    private var cOnContainer = 0
    private var cText = 0
    private var cSub = 0
    private var cErr = 0
    private var cRipple = 0

    // views
    private lateinit var content: LinearLayout
    private lateinit var tvStatusTitle: TextView
    private lateinit var tvStatusSub: TextView
    private lateinit var tvShizuku: TextView
    private lateinit var btnAllow: TextView
    private lateinit var angleNote: View
    private lateinit var gamesCard: View
    private lateinit var tvGames: TextView
    private lateinit var tvTexSub: TextView
    private lateinit var options: LinearLayout
    private lateinit var segMode: Segments
    private lateinit var segLevel: Segments
    private lateinit var tvLevel: TextView
    private lateinit var btnSave: TextView
    private lateinit var btnRestore: TextView

    // navigation + FPS page
    private var page = 0
    private var fpsOn = false
    private var fpsPos = 0
    private var fpsSize = 1
    private var fpsOpa = 1
    private var fpsInt = 1
    private lateinit var pageTex: View
    private lateinit var pageFps: View
    private lateinit var nav: LinearLayout
    private val tabs = arrayOfNulls<LinearLayout>(2)
    private val tabIcons = arrayOfNulls<ImageView>(2)
    private val tabLabels = arrayOfNulls<TextView>(2)
    private lateinit var swFps: Switch
    private lateinit var tvFpsSub: TextView
    private lateinit var tvOverlay: TextView
    private lateinit var tvPreview: TextView
    private lateinit var segPos: Segments
    private lateinit var segSize: Segments
    private lateinit var segOpa: Segments
    private lateinit var segInt: Segments

    private var lA: Shizuku.OnBinderReceivedListener? = null
    private var lB: Shizuku.OnBinderDeadListener? = null
    private var lC: Shizuku.OnRequestPermissionResultListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        picked = prefs.getString("sel", "")!!.split(",").filter { it.isNotEmpty() }.toSet()
        applied = prefs.getBoolean("applied", false)
        pixel = prefs.getBoolean("pixel", false)
        level = prefs.getInt("level", 4)
        aPixel = pixel
        aLevel = level
        aCount = prefs.getInt("count", 0)
        fpsOn = prefs.getBoolean("fps_on", false)
        fpsPos = prefs.getInt("fps_pos", 0).coerceIn(0, 2)
        fpsSize = prefs.getInt("fps_size", 1).coerceIn(0, 2)
        fpsOpa = prefs.getInt("fps_opa", 1).coerceIn(0, 2)
        fpsInt = prefs.getInt("fps_int", 1).coerceIn(0, 2)

        initPalette()
        setContentView(buildRoot())
        render(false)
        playEntrance()

        // First launch after install: show the info once.
        if (!prefs.getBoolean("info_seen", false)) {
            content.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    prefs.edit().putBoolean("info_seen", true).apply()
                    showAbout()
                }
            }, 600)
        }

        try {
            val a = Shizuku.OnBinderReceivedListener { refresh() }
            val b = Shizuku.OnBinderDeadListener { refresh() }
            val c = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
            lA = a; lB = b; lC = c
            Shizuku.addBinderReceivedListenerSticky(a)
            Shizuku.addBinderDeadListener(b)
            Shizuku.addRequestPermissionResultListener(c)
        } catch (_: Throwable) { }

        refresh()
        loadGames()
    }

    override fun onResume() {
        super.onResume()
        fpsOn = prefs.getBoolean("fps_on", false)
        if (fpsOn && !Settings.canDrawOverlays(this)) {
            fpsOn = false
            prefs.edit().putBoolean("fps_on", false).apply()
        } else if (fpsOn) {
            startFps()
        }
        render(false)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (page != 0) setPage(0) else super.onBackPressed()
    }

    override fun onDestroy() {
        try {
            lA?.let { Shizuku.removeBinderReceivedListener(it) }
            lB?.let { Shizuku.removeBinderDeadListener(it) }
            lC?.let { Shizuku.removeRequestPermissionResultListener(it) }
        } catch (_: Throwable) { }
        io.shutdown()
        super.onDestroy()
    }

    // ───────── data ─────────

    @Suppress("DEPRECATION")
    private fun findGamesSync(): List<Game> {
        val pm = packageManager
        return pm.getInstalledApplications(0)
            .asSequence()
            .filter { it.packageName != packageName }
            .filter {
                it.category == ApplicationInfo.CATEGORY_GAME ||
                        (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || it.packageName in KNOWN
            }
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { Game(pm.getApplicationLabel(it).toString(), it.packageName) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    private fun loadGames() = io.execute {
        val g = findGamesSync()
        runOnUiThread { games = g; render(false) }
    }

    private fun refresh() {
        if (io.isShutdown) return
        io.execute {
            val r = Shell.running()
            val g = Shell.granted()
            runOnUiThread {
                running = r
                granted = g
                render(false)
                if (g && angle == null) cekAngle()
            }
        }
    }

    private fun requestPerm() {
        try { Shizuku.requestPermission(1) } catch (_: Throwable) { }
    }

    private fun cekAngle() {
        if (!running) toast("Start Shizuku first")
        else if (!granted) requestPerm()
        else io.execute {
            val out = Shell.run(ANGLE_CMD).second
            runOnUiThread { angle = out.contains("lib"); render(false) }
        }
    }

    private fun jalankan(cmd: String, ok: () -> Unit) {
        if (!granted) { toast("Shizuku not ready"); return }
        busy = true
        render(false)
        io.execute {
            val r = Shell.run(cmd)
            runOnUiThread {
                busy = false
                if (r.first == 0) ok() else toast("Failed: ${r.second.take(80)}")
                render(true)
            }
        }
    }

    private fun restore() {
        val pkgs = prefs.getString("pkgs", "")!!.split(",").filter { PKG_OK.matches(it) }
        jalankan(restoreCmd(pkgs)) {
            applied = false
            prefs.edit().putBoolean("applied", false).apply()
            toast("Restored to default")
        }
    }

    private fun simpan() {
        val pkgs = picked.filter { PKG_OK.matches(it) }
        if (pkgs.isEmpty()) { toast("Select at least one game"); return }
        val px = pixel
        val lv = level
        jalankan(applyCmd(pkgs, px, lv)) {
            applied = true
            aPixel = px
            aLevel = lv
            aCount = pkgs.size
            prefs.edit().putBoolean("applied", true).putBoolean("pixel", px)
                .putInt("level", lv).putInt("count", pkgs.size)
                .putString("sel", pkgs.joinToString(",")).putString("pkgs", pkgs.joinToString(","))
                .apply()
            toast("Saved. Reopen the game")
        }
    }

    // ───────── render ─────────

    private fun render(animate: Boolean) {
        if (animate) TransitionManager.beginDelayedTransition(content, AutoTransition().setDuration(200))

        tvStatusTitle.text = if (applied) "Active" else "Default"
        tvStatusSub.text = if (applied)
            "Level $aLevel · ${if (aPixel) "Pixel" else "Blur"} · $aCount game${if (aCount == 1) "" else "s"}"
        else "Original textures"

        tvShizuku.text = when {
            !running -> "Not running"
            !granted -> "Permission needed"
            else -> "Connected"
        }
        btnAllow.visibility = if (running && !granted) View.VISIBLE else View.GONE
        angleNote.visibility = if (angle == false) View.VISIBLE else View.GONE

        tvGames.text = if (picked.isEmpty()) "Tap to choose"
        else picked.joinToString(", ") { p -> games.firstOrNull { it.pkg == p }?.label ?: p }

        // Texture controls are locked until at least one game is selected.
        val unsupported = angle == false
        gamesCard.alpha = if (unsupported) 0.4f else 1f
        val ready = picked.isNotEmpty() && !unsupported
        tvTexSub.text = when {
            unsupported -> "Not available on this device"
            ready -> "Reduce texture detail"
            else -> "Select a game first"
        }
        options.alpha = if (ready) 1f else 0.4f
        segMode.select(if (pixel) 1 else 0)
        segLevel.select(level - 1)
        tvLevel.text = "$level · " + when (level) { 1 -> "Light"; 2 -> "Medium"; 3 -> "Strong"; else -> "Lowest" }

        val canSave = ready && !busy
        btnSave.isEnabled = canSave
        btnSave.alpha = if (canSave) 1f else 0.4f
        btnSave.text = if (busy) "Saving…" else "Save changes"
        btnRestore.visibility = if (applied) View.VISIBLE else View.GONE
        btnRestore.isEnabled = !busy
        renderFps()
    }

    // ───────── UI building ─────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun sys(id: Int, fallback: Int) = if (Build.VERSION.SDK_INT >= 31) getColor(id) else fallback

    @Suppress("DEPRECATION")
    private fun initPalette() {
        night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (night) {
            cBg = sys(android.R.color.system_neutral1_900, 0xFF121214.toInt())
            cCard = sys(android.R.color.system_neutral1_800, 0xFF1F1F23.toInt())
            cAccent = sys(android.R.color.system_accent1_200, 0xFFD0BCFF.toInt())
            cOnAccent = sys(android.R.color.system_accent1_800, 0xFF381E72.toInt())
            cContainer = sys(android.R.color.system_accent1_700, 0xFF4F378B.toInt())
            cOnContainer = sys(android.R.color.system_accent1_100, 0xFFEADDFF.toInt())
            cText = sys(android.R.color.system_neutral1_100, 0xFFE6E1E5.toInt())
            cSub = sys(android.R.color.system_neutral2_300, 0xFFCAC4D0.toInt())
            cErr = 0xFFF2B8B5.toInt()
            cRipple = 0x33FFFFFF
        } else {
            cBg = sys(android.R.color.system_neutral1_10, 0xFFFEF7FF.toInt())
            cCard = sys(android.R.color.system_neutral1_100, 0xFFECE6F0.toInt())
            cAccent = sys(android.R.color.system_accent1_600, 0xFF6750A4.toInt())
            cOnAccent = Color.WHITE
            cContainer = sys(android.R.color.system_accent1_100, 0xFFEADDFF.toInt())
            cOnContainer = sys(android.R.color.system_accent1_900, 0xFF21005D.toInt())
            cText = sys(android.R.color.system_neutral1_900, 0xFF1D1B20.toInt())
            cSub = sys(android.R.color.system_neutral2_700, 0xFF49454F.toInt())
            cErr = 0xFFB3261E.toInt()
            cRipple = 0x22000000
        }
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (!night) {
            if (Build.VERSION.SDK_INT >= 30) {
                val m = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                window.insetsController?.setSystemBarsAppearance(m, m)
            } else {
                window.decorView.systemUiVisibility =
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
        }
    }

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun ripple(content: android.graphics.drawable.Drawable?, r: Int) =
        RippleDrawable(ColorStateList.valueOf(cRipple), content, rounded(Color.WHITE, r))

    private fun tv(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun subText() = tv(14f, cSub).apply {
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun card(bg: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(bg, 20)
    }

    private fun item(title: String, sub: TextView, trailing: View?): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val col = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(16f, cText))
                (getChildAt(0) as TextView).text = title
                addView(sub)
            }
            addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (trailing != null) {
                addView(trailing, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(12) })
            }
        }

    private fun smallButton(text: String, onClick: () -> Unit) = tv(14f, cOnContainer, true).apply {
        this.text = text
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(8), dp(16), dp(8))
        background = ripple(rounded(cContainer, 20), 20)
        setOnClickListener { onClick() }
        bounce()
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit) =
        tv(16f, if (filled) cOnAccent else cErr, true).apply {
            this.text = text
            gravity = Gravity.CENTER
            background = if (filled) ripple(rounded(cAccent, 26), 26)
            else ripple(GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), cErr)
                cornerRadius = dp(26).toFloat()
            }, 26)
            setOnClickListener { onClick() }
            bounce()
        }

    // press-scale feedback: draws only, no re-layout
    @Suppress("ClickableViewAccessibility")
    private fun View.bounce() {
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(110).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
    }

    private inner class Segments(
        labels: List<String>,
        private val onPick: (Int) -> Unit
    ) {
        val view = LinearLayout(this@MainActivity)
        private val items = ArrayList<TextView>()

        init {
            view.orientation = LinearLayout.HORIZONTAL
            labels.forEachIndexed { i, l ->
                val t = tv(14f, cText, true).apply {
                    text = l
                    gravity = Gravity.CENTER
                    setOnClickListener { onPick(i) }
                }
                items.add(t)
                view.addView(t, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
                    if (i > 0) leftMargin = dp(4)
                })
            }
        }

        fun select(i: Int) {
            items.forEachIndexed { k, t ->
                val on = k == i
                t.background = rounded(if (on) cAccent else cBg, 20)
                t.setTextColor(if (on) cOnAccent else cText)
            }
        }
    }

    private fun lp(bottom: Int = 12) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(bottom) }

    private fun buildUi(): View {
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(110))
        }

        // title
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_launcher_foreground)
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = rounded(getColor(R.color.ic_launcher_background), 14)
            }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { rightMargin = dp(14) })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(30f, cText, true).apply { text = "LowGX" })
                addView(tv(14f, cSub).apply { text = "Texture optimizer for games" })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_info)
                imageTintList = ColorStateList.valueOf(cOnContainer)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(8), dp(8), dp(8), dp(8))
                contentDescription = "About LowGX"
                background = ripple(rounded(cContainer, 20), 20)
                setOnClickListener { showAbout() }
                bounce()
            }, LinearLayout.LayoutParams(dp(40), dp(40)))
        }, lp())

        // status
        tvStatusTitle = tv(22f, cOnContainer, true)
        tvStatusSub = tv(14f, cOnContainer)
        content.addView(card(cContainer).apply {
            setPadding(dp(20), dp(20), dp(20), dp(20))
            addView(tvStatusTitle)
            addView(tvStatusSub)
        }, lp())

        // system
        tvShizuku = subText()
        btnAllow = smallButton("Allow") { requestPerm() }
        content.addView(card(cCard).apply {
            addView(item("Shizuku", tvShizuku, btnAllow))
            angleNote = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(if (night) 0xFF601410.toInt() else 0xFFF9DEDC.toInt(), 16)
                addView(ImageView(context).apply {
                    setImageResource(R.drawable.ic_info)
                    imageTintList = ColorStateList.valueOf(cErr)
                }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(12) })
                addView(tv(14f, if (night) 0xFFFFDAD6.toInt() else 0xFF410E0B.toInt()).apply {
                    text = "This device does not support ANGLE. The features in this app will not work."
                    setLineSpacing(0f, 1.1f)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                visibility = View.GONE
            }
            addView(angleNote, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(12) })
        }, lp())

        // games
        tvGames = subText()
        gamesCard = card(cCard).apply {
            addView(item("Select games", tvGames, null))
            foreground = ripple(null, 20)
            isClickable = true
            setOnClickListener {
                if (angle == false) toast("ANGLE is not supported on this device") else showPicker()
            }
            bounce()
        }
        content.addView(gamesCard, lp())

        // texture
        tvTexSub = subText()
        val texRow = item("Low Texture", tvTexSub, null)
        segMode = Segments(listOf("Blur", "Pixel")) {
            if (angle == false) toast("ANGLE is not supported on this device") else if (picked.isEmpty()) toast("Select a game first") else { pixel = it == 1; render(false) }
        }
        segLevel = Segments(listOf("1", "2", "3", "4")) {
            if (angle == false) toast("ANGLE is not supported on this device") else if (picked.isEmpty()) toast("Select a game first") else { level = it + 1; render(false) }
        }
        tvLevel = tv(16f, cAccent, true)
        options = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(16))
            addView(segMode.view)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(16), 0, dp(8))
                addView(tv(16f, cText, true).apply { text = "Texture level" },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(tvLevel)
            })
            addView(segLevel.view)
            addView(tv(12f, cSub).apply {
                text = "Higher number = lower graphics quality and better performance."
                setPadding(0, dp(10), 0, 0)
            })
        }
        content.addView(card(cCard).apply {
            addView(texRow)
            addView(options)
        }, lp())

        // actions
        btnSave = button("Save changes", true) { if (!busy) simpan() }
        btnRestore = button("Restore default", false) { if (!busy) restore() }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(btnSave, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
            addView(btnRestore, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
                .apply { topMargin = dp(8) })
        }, lp(0))

        return ScrollView(this).apply {
            setBackgroundColor(cBg)
            isFillViewport = true
            addView(content)
        }
    }

    // ───────── navigation + FPS page ─────────

    private fun buildRoot(): View {
        pageTex = buildUi()
        pageFps = buildFpsPage()
        pageFps.visibility = View.GONE
        nav = buildNav()
        return FrameLayout(this).apply {
            setBackgroundColor(cBg)
            addView(pageTex, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(pageFps, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(nav, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(64),
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = dp(20) })
        }
    }

    private fun buildNav(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(cAccent, 32)
            elevation = dp(6).toFloat()
        }
        fun tab(i: Int, icon: Int, label: String) {
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                minimumWidth = dp(52)
                setOnClickListener { setPage(i) }
                bounce()
            }
            val iv = ImageView(this).apply { setImageResource(icon) }
            val lb = tv(14f, cAccent, true).apply {
                text = label
                setPadding(dp(8), 0, 0, 0)
            }
            t.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            t.addView(lb)
            tabs[i] = t; tabIcons[i] = iv; tabLabels[i] = lb
            bar.addView(t, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(52)))
        }
        tab(0, R.drawable.ic_layers, "Texture")
        tab(1, R.drawable.ic_speed, "FPS")
        styleTabs()
        return bar
    }

    private fun styleTabs() {
        for (i in 0..1) {
            val sel = i == page
            tabs[i]!!.background = if (sel) rounded(cBg, 26) else null
            tabs[i]!!.setPadding(if (sel) dp(20) else dp(14), 0, if (sel) dp(20) else dp(14), 0)
            tabIcons[i]!!.imageTintList = ColorStateList.valueOf(if (sel) cAccent else cOnAccent)
            tabLabels[i]!!.visibility = if (sel) View.VISIBLE else View.GONE
        }
    }

    private fun setPage(i: Int) {
        if (i == page) return
        page = i
        TransitionManager.beginDelayedTransition(nav, AutoTransition().setDuration(220))
        styleTabs()
        val to = if (i == 0) pageTex else pageFps
        val from = if (i == 0) pageFps else pageTex
        from.visibility = View.GONE
        to.alpha = 0f
        to.visibility = View.VISIBLE
        to.animate().alpha(1f).setDuration(200).start()
    }

    private fun iconBadge(res: Int) = ImageView(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(cOnContainer)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = rounded(cContainer, 22)
    }

    private fun iconItem(res: Int, title: String, sub: TextView, trailing: View?): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            addView(iconBadge(res), LinearLayout.LayoutParams(dp(44), dp(44))
                .apply { rightMargin = dp(16) })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(16f, cText, true).apply { text = title })
                addView(sub)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (trailing != null) {
                addView(trailing, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(12) })
            }
        }

    private fun tapCard(inner: View, onClick: () -> Unit) = card(cCard).apply {
        addView(inner)
        foreground = ripple(null, 20)
        isClickable = true
        setOnClickListener { onClick() }
        bounce()
    }

    private fun section(t: String) = tv(14f, cAccent, true).apply {
        text = t
        setPadding(dp(8), dp(16), 0, dp(8))
    }

    private fun fieldLabel(t: String) = tv(16f, cText, true).apply {
        text = t
        setPadding(0, dp(16), 0, dp(8))
    }

    private fun fpsChanged() {
        render(false)
        if (fpsOn) startFps()
    }

    private fun buildFpsPage(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(110))
        }

        col.addView(tv(30f, cText, true).apply {
            text = "FPS counter"
            gravity = Gravity.CENTER_VERTICAL
            minHeight = dp(52)
            setPadding(dp(4), dp(8), 0, dp(8))
        }, lp(4))

        // overlay
        col.addView(section("Overlay"), lp(0))
        tvFpsSub = subText()
        swFps = Switch(this).apply {
            val on = intArrayOf(android.R.attr.state_checked)
            val off = intArrayOf()
            trackTintList = ColorStateList(arrayOf(on, off), intArrayOf(cAccent, cBg))
            thumbTintList = ColorStateList(arrayOf(on, off), intArrayOf(cOnAccent, cSub))
            isClickable = false
            isFocusable = false
        }
        col.addView(tapCard(iconItem(R.drawable.ic_speed, "Floating FPS counter", tvFpsSub, swFps)) {
            toggleFps()
        }, lp(4))

        tvOverlay = subText()
        val chevron = ImageView(this).apply {
            setImageResource(R.drawable.ic_chevron)
            imageTintList = ColorStateList.valueOf(cSub)
        }
        col.addView(tapCard(iconItem(R.drawable.ic_overlay, "Display over other apps", tvOverlay, chevron)) {
            openOverlaySettings()
        }, lp(4))

        // appearance
        col.addView(section("Appearance"), lp(0))
        tvPreview = tv(15f, Color.WHITE, true).apply {
            text = "60 FPS"
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val previewBox = FrameLayout(this).apply {
            background = rounded(cBg, 14)
            addView(tvPreview, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(12), 0, dp(12), 0) })
        }
        segPos = Segments(listOf("Left", "Center", "Right")) {
            fpsPos = it; prefs.edit().putInt("fps_pos", it).apply(); fpsChanged()
        }
        segSize = Segments(listOf("Small", "Medium", "Large")) {
            fpsSize = it; prefs.edit().putInt("fps_size", it).apply(); fpsChanged()
        }
        segOpa = Segments(listOf("40%", "65%", "90%")) {
            fpsOpa = it; prefs.edit().putInt("fps_opa", it).apply(); fpsChanged()
        }
        col.addView(card(cCard).apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(previewBox, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(76)))
            addView(fieldLabel("Position"))
            addView(segPos.view)
            addView(fieldLabel("Text size"))
            addView(segSize.view)
            addView(fieldLabel("Background opacity"))
            addView(segOpa.view)
        }, lp(4))

        // update rate
        col.addView(section("Update rate"), lp(0))
        segInt = Segments(listOf("0.5 s", "1 s", "2 s")) {
            fpsInt = it; prefs.edit().putInt("fps_int", it).apply(); fpsChanged()
        }
        col.addView(card(cCard).apply {
            setPadding(dp(16), 0, dp(16), dp(16))
            addView(fieldLabel("Refresh every"))
            addView(segInt.view)
            addView(tv(12f, cSub).apply {
                text = "Faster updates use a little more battery. FPS is read through Shizuku."
                setPadding(0, dp(10), 0, 0)
            })
        }, lp(4))

        return ScrollView(this).apply {
            setBackgroundColor(cBg)
            isFillViewport = true
            addView(col)
        }
    }

    private fun renderFps() {
        swFps.isChecked = fpsOn
        tvFpsSub.text = when {
            !granted -> "Requires Shizuku"
            fpsOn -> "Running"
            else -> "Show a floating FPS counter"
        }
        tvOverlay.text = if (Settings.canDrawOverlays(this)) "Allowed" else "Required · tap to allow"
        segPos.select(fpsPos)
        segSize.select(fpsSize)
        segOpa.select(fpsOpa)
        segInt.select(fpsInt)
        tvPreview.setTextSize(TypedValue.COMPLEX_UNIT_SP, FPS_SP[fpsSize])
        tvPreview.setPadding(dp(10), dp(5), dp(10), dp(5))
        tvPreview.background = rounded(Color.argb(FPS_OPA[fpsOpa], 0, 0, 0), 10)
        (tvPreview.layoutParams as FrameLayout.LayoutParams).gravity = Gravity.CENTER_VERTICAL or when (fpsPos) {
            0 -> Gravity.START
            1 -> Gravity.CENTER_HORIZONTAL
            else -> Gravity.END
        }
        tvPreview.requestLayout()
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (_: Throwable) {
            toast("Open Settings and allow display over other apps")
        }
    }

    private fun toggleFps() {
        if (fpsOn) { setFps(false); return }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow display over other apps first")
            openOverlaySettings()
            return
        }
        if (!granted) {
            if (!running) toast("Start Shizuku first") else { toast("Allow Shizuku access first"); requestPerm() }
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        setFps(true)
    }

    private fun setFps(on: Boolean) {
        fpsOn = on
        prefs.edit().putBoolean("fps_on", on).apply()
        if (on) startFps() else stopService(Intent(this, FpsService::class.java))
        render(true)
    }

    private fun startFps() {
        try {
            startForegroundService(Intent(this, FpsService::class.java))
        } catch (_: Throwable) {
            fpsOn = false
            prefs.edit().putBoolean("fps_on", false).apply()
            toast("Could not start the FPS counter")
        }
    }

    // ───────── about ─────────

    private fun showAbout() {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "" }

        fun heading(t: String) = tv(14f, cText, true).apply { text = t }
        fun body(t: String) = tv(14f, cSub).apply {
            text = t
            setLineSpacing(0f, 1.15f)
            setPadding(0, dp(6), 0, dp(14))
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(8))

            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(16))
                addView(ImageView(context).apply {
                    setImageResource(R.drawable.ic_launcher_foreground)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    background = rounded(getColor(R.color.ic_launcher_background), 14)
                }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(14) })
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(tv(20f, cText, true).apply { text = "LowGX" })
                    addView(tv(12f, cSub).apply { text = "Version $ver" })
                })
            })

            addView(heading("About"))
            addView(body(
                "LowGX reduces texture detail in the games you choose, helping them run " +
                        "smoother on low-end devices. It works through the system ANGLE graphics " +
                        "driver and requires Shizuku."
            ))
            addView(heading("How to use"))
            addView(body(
                "1. Start Shizuku and allow access.\n" +
                        "2. Select your games.\n" +
                        "3. Choose a mode and a texture level.\n" +
                        "4. Save, then reopen the game."
            ))
            addView(heading("Texture level"))
            addView(body(
                "Levels 1 to 4 set how much texture detail is removed. The higher the number, " +
                        "the lower the graphics quality and the lighter the game runs. " +
                        "Level 1 is a light reduction, level 4 is the lowest quality for maximum performance."
            ))
            addView(heading("FPS counter"))
            addView(body(
                "Open the FPS tab, allow display over other apps, then switch the counter on. " +
                        "It shows the frame rate of the app in front and needs Shizuku."
            ))
            addView(heading("Good to know"))
            addView(body(
                "Blur softens textures, Pixel makes them blocky for a bigger boost. " +
                        "Changes only affect the selected games and can be undone anytime with Restore default."
            ))
        }

        val scroll = ScrollView(this).apply { addView(box) }
        val dialog = AlertDialog.Builder(this)
            .setView(scroll)
            .setPositiveButton("Got it", null)
            .create()
        dialog.window?.setBackgroundDrawable(rounded(cCard, 24))
        dialog.show()
    }

    private fun playEntrance() {
        for (i in 0 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(36).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 45L).setDuration(380)
                .setInterpolator(DecelerateInterpolator())
                .withLayer().start()
        }
    }

    // ───────── game picker ─────────

    private fun newPickRow(): PickHolder {
        val name = tv(16f, cText).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val pkg = tv(12f, cSub).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val check = CheckBox(this).apply { isClickable = false; isFocusable = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(name)
                addView(pkg)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(check)
        }
        return PickHolder(root, name, pkg, check)
    }

    private fun showPicker() {
        val list = ArrayList<Game>(games)
        val adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int) = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val h: PickHolder
                if (convertView == null) {
                    h = newPickRow()
                    h.root.tag = h
                } else {
                    h = convertView.tag as PickHolder
                }
                val g = list[position]
                h.name.text = g.label
                h.pkg.text = g.pkg
                h.check.isChecked = g.pkg in picked
                return h.root
            }
        }

        val search = EditText(this).apply {
            hint = "Search games"
            isSingleLine = true
            setTextColor(cText)
            setHintTextColor(cSub)
        }
        val empty = tv(14f, cSub).apply {
            text = if (games.isEmpty()) "No games found" else "No match"
            setPadding(0, dp(24), 0, dp(24))
        }
        val lv = ListView(this).apply {
            divider = null
            this.adapter = adapter
            emptyView = empty
            setOnItemClickListener { _, _, pos, _ ->
                val pkg = list[pos].pkg
                picked = if (pkg in picked) picked - pkg else picked + pkg
                adapter.notifyDataSetChanged()
                render(true)
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val key = s?.toString()?.trim().orEmpty()
                list.clear()
                list.addAll(
                    if (key.isEmpty()) games
                    else games.filter { it.label.contains(key, true) || it.pkg.contains(key, true) }
                )
                adapter.notifyDataSetChanged()
            }
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(search)
            addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340)))
            addView(empty)
        }

        AlertDialog.Builder(this)
            .setTitle("Select games")
            .setView(box)
            .setPositiveButton("Done", null)
            .show()
    }
}
