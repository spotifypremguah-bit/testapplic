plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.lowgx.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.lowgx.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 12
        versionName = "4.5"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf("-Xno-param-assertions", "-Xno-call-assertions", "-Xno-receiver-assertions")
    }
    packaging {
        resources {
            excludes += listOf(
                "/META-INF/*.version", "/META-INF/*.kotlin_module", "/kotlin/**",
                "/DebugProbesKt.bin", "/kotlin-tooling-metadata.json"
            )
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
